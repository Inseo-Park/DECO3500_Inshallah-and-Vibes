# ECHO — the installation at The UQ Lakes

Built for an **iPad held in portrait**, and it fills a laptop screen too.
Open `index.html`. No internet, no account, no password, no install.

```
ECHO-lakes/
  index.html            <- open this
  relay.js              the link between two laptops (plain Node, no packages)
  start-link.command    double-click on a Mac
  start-link.bat        double-click on Windows
  PHOTO-CREDITS.md      real photographs: licences, credits, how to add them
  get-photos.sh / .ps1  one command to fetch them
  media/                the archive films, voices and photographs
```

This build is the ECHO standing at **The UQ Lakes**. On the island, The UQ Lakes is the one
place that is open. The Great Court, Forgan Smith, Duhig and the ferry terminal are
**in the mist** — you can half-see what is under there, and the plaque tells
you there's an ECHO at that place and you have to go to it. That is the point:
one installation opens one place, and the island is an argument for walking to
the others.

## The front of it

Two doors: **Discover UQ** and **the UQ social garden**. A **tree button**
sits next to the language button on every screen, so the garden is one tap
away from anywhere.

## In the garden

You walk, by default. On the map there is only:

- the **search field** and the **+**, top right, with the **≡ menu** and the
  **⚑ My tree** flag under them;
- the **walking pad**, bottom left — a thin four-way cross that fades back when
  you aren't touching it;
- the **bubble** that appears when you're standing next to something:
  *Look around · Talk to them · Walk in*.

Everything else is in the **≡ menu**: the walkthrough again, the whole island,
your tree, how many ECHOes are live around campus, the **Link**, and language.

You cannot walk off the island any more. The shore stops you.

## The walkthrough

Six cards, each under a dozen words, and each one takes the camera to the thing
it names and rings it: you, the walking pad, the one open landmark, your own
tree, somebody else's tree, and a person you can walk up to and talk to.
**How this works** in the menu runs it again.

## Signing out

The front of the prototype has a **Sign out** button, and so does the garden's
≡ menu. It hands the prototype back to the next person at the "who are you
here as?" screen. The iPad still remembers the last ID, so coming back is one
tap — nothing anybody left is deleted.

## Linking two ECHOes

Full instructions are in the README one folder up, including the laptop-and-iPad
setup. Short version:

- **A laptop and an iPad.** Run `start-link.command` / `start-link.bat` at the
  top of the `ECHO-v22` folder on the laptop. It prints an address like
  `http://192.168.x.x:8787/`. Open that on the iPad, on the same wi-fi, and pick
  the other installation. Both join by themselves — nothing to type.
- **Two laptops with their own copies.** Run the same script on one of them and
  type the short code it prints into the Link panel on both.
- **Two windows on one laptop.** They find each other with nothing running.
- **Nothing available.** The conversations stay written, and the prototype says
  so rather than pretending.

## What's simulated

The people in the garden and what they say are written for this prototype and
labelled as written. A **live** person — someone at the other ECHO — carries a
green LIVE badge and a live conversation says so. Drawn pictures are marked
SIMULATED IMAGE. The documented history carries its sources. Nothing in here
speaks for Aboriginal or Torres Strait Islander people; the seventh theme
carries a notice explaining how that material would have to be made.
