# ECHO — UQ Lakes listening pod prototype

---

## ⚠️ START HERE — how to open it

**Keep this whole folder together.** The page loads the film, the audio and the
images from the `media` folder sitting next to it. Open `index.html` on its own
and you get a black screen with no story, because there is nothing there to play.

1. Unzip `ECHO.zip` somewhere sensible — Desktop or Documents, **not** Downloads
   (files scattered in Downloads is exactly how the folder gets split up).
2. Open the `ECHO` folder. You should see:

   ```
   ECHO/
     index.html      ← this is the one you open
     README.md
     media/
       echo-027-video.mp4
       echo-027-audio.mp3
       …
   ```
3. Double-click **`index.html`**.

That's it. **No server, no Supabase, no database, no internet.** It runs entirely
off the file on your machine, which is what you want in a pod at UQ Lakes where
there may be no usable wifi.

If you ever see the screen that says *"The Echo can't find its recording"*, that
always means the same thing: `index.html` has been separated from `media`.

**Browser:** Chrome or Edge. Both play the .mp4 and both allow the microphone
from a local file, which the voice recording needs. Firefox will run the flow but
can be fussy about the microphone from a local file.

---

## What the prototype does

A student walks up to the pod and sees only the invitation — **ECHO**, the
location, and *touch to begin*. Nothing explains itself yet; that's deliberate
(§39). The moment they touch it, the two doors open: listen, or leave something.

The full path:

```
LANDING  →  WHAT'S AN ECHO  →  listen or share
                                  │
   listen ────────────────────────┤
     What are you curious about?  │
     → subtopic → finding…        │
     → ECHO #027                  │
        ├─ choose: watch it, or listen to it
        ├─ [first medium plays] → how did that feel? + why
        ├─ "now try the other one" → [second medium plays] → how did that feel? + why
        └─ which way did you want this story? + why
     → what stayed with you?      │
                                  │
   share ─────────────────────────┘
     what would you leave? (6 types)
     → write, record, or show
     → confirm → ECHO LEFT → end
```

**Every curiosity path leads to the same story.** *This place*, *the people*,
*what happened here*, *surprise me*, and every subtopic under them all open Echo
#027 — because #027 is the only story that has actually been produced. The choice
screens aren't there to serve different content; they're there to record **which
door a student opens**. Every one of those choices is logged faithfully in
`curiosity`, `subtopic` and `clicks`, so you still learn what they reached for
even though everyone ends up in the same place. (To branch for real later, see
`ROUTES` in `index.html` — Echoes 014 and 039 are still defined and ready.)

**Every participant experiences both the film and the audio**, in whichever order
they choose. Which one they reach for first is recorded, and so is how far they
got through each, what each one made them feel, and which they preferred once
they'd had both. That's a within-subjects comparison — stronger than the
between-subjects A/B in §36 of the spec, because each participant is their own
control, and you need far fewer people to see a pattern.

**One thing to watch:** both pieces back to back is about 9½ minutes, well over
the 3–5 minute target in §58. The *I'm done* button in the player and the *Skip
this* link on the second-pass screen both exist for that reason — a participant
can move on the moment they've got the feel of it, and how long they lasted is
itself part of the data.

---

## Where the responses are, and how to get them out

Responses are saved on the machine as each participant goes, not at the end — so
closing the lid or a flat battery mid-session doesn't lose anyone.

### Three ways in — use whichever you'll remember

**On an iPad, press and hold the small round data icon** in the bottom-right
corner for about a second — a ring fills as you hold, then the responses open.
It only appears on the opening and closing screens, so it never sits on top of
the player, and participants never meet it mid-story. A stray tap won't open it.

Tap **Save CSV** there and iPadOS opens its share sheet: **Save to Files**, mail
it to yourself, or AirDrop it. That's the route that works on an iPad — Safari
won't do an ordinary download from a locally opened file. On a laptop the same
button downloads normally, and if that fails it copies to the clipboard or shows
the CSV as selectable text.

The keyboard and address-bar routes still work on a laptop:

**1. The address bar (easiest — bookmark it).** Add `#responses` to the end of the
address and press Enter:

```
C:/Users/itish/OneDrive/Desktop/ECHO_1/ECHO/index.html#responses
```

Bookmark that once and the records are a single click away, forever.

**2. Keyboard.** Press **Ctrl + Shift + D** (**Cmd + Shift + D** on Mac). A dark
tester panel appears top-right → **View all responses**.

**3. Touch, for when the pod has no keyboard.** **Press and hold the middle of the
very top edge** of the screen for about a second. (Triple-tapping the same spot
opens the tester panel instead.)

All three are invisible to participants, which is the point (§36) — don't open
them in front of someone.

### What you get

A readable card per participant: which door they opened, how long before they
touched the screen at all, how far they got through the film and the audio, what
each one made them feel in their own words, which they preferred, and the Echo
they left. At the bottom of each card, **Every tap** — the complete click trail
with timings, so you can see exactly what they did and when.

**To download:** **Download CSV**, in the responses view or the tester panel. One
row per participant, opens straight in Excel or Google Sheets.

### What's in the CSV

| Column | What it holds |
|---|---|
| `id`, `started`, `ended` | session identity and timing |
| `entry` | whether they arrived via listen or share |
| `time_to_touch_s` | seconds between the invitation appearing and their first touch — your attraction measure |
| `curiosity`, `subtopic` | which door they opened |
| `first_medium` | **which one they chose first** — the order effect |
| `video_seconds`, `video_pct`, `video_completed` | how far they got through the film |
| `video_reaction`, `video_reaction_why` | how the film made them feel, in their words |
| `audio_seconds`, `audio_pct`, `audio_completed` | how far they got through the audio |
| `audio_reaction`, `audio_reaction_why` | how the audio made them feel, in their words |
| `preferred_medium`, `preferred_why` | **the research question**, asked only once they'd had both |
| `takeaway`, `takeaway_why` | what stayed with them |
| `echo_type`, `echo_format`, `echo_text`, `echo_audio_seconds` | what they left, and how |
| `echo_left` | whether they actually went through with it |
| `path` | every screen they touched, in order — useful for spotting where people stall |
| `clicks` | **the complete tap trail with timings** — every choice, play, pause, seek and skip, in order |

**Clearing between rounds:** the tester panel's **Clear** button wipes everything
on that machine and asks once before it does. Download the CSV first.

---

## Voice recordings

*Record* is live and works. Tap the red circle, speak, tap again to stop, then
play it back and either keep it or record again. There's a live level meter drawn
from the actual microphone, and a 60-second cap.

The first time, the browser asks for microphone permission — **allow it before
your first participant**, not during.

**Important:** recordings are held in the page's memory, not on disk, because
there's no backend. They're listed in the tester panel under **Voice Echoes**
with a **Download all** button.

> **Download recordings before you reload or close the page, or they're gone.**

If the microphone is blocked or unavailable, the screen says so and offers to let
the participant write instead, rather than dead-ending. That fallback is recorded
in the CSV as `write_after_record_failed`, which is worth knowing about.

---

## Swapping the media

Drop a replacement into `media/` under the same filename and it just works.

| File | What it is |
|---|---|
| `echo-027-video.mp4` | the film — currently 720p, 3:57 |
| `echo-027-audio.mp3` | the audio documentary — 5:32 |
| `echo-027-still-modeb.jpg` | the single still behind the audio-only mode |
| `landing-greatcourt.jpg` | the landing screen ground |
| `end-greatcourt.jpg` | the end screen |
| `echo-027-poster.jpg` | the frame shown before the film starts |

The shipped film is a 720p, 24 MB version so the whole package stays a reasonable
download. The full 1080p, 95 MB master is available if you want it — just drop it
in under the same name. On a tablet the 720p is honestly hard to tell apart.

If you replace the audio with a different recording, the waveform will no longer
match it. The waveform is drawn from a measured amplitude map embedded in
`index.html` (search for `ENVELOPES`), because a browser won't let a page analyse
a local audio file live. Ask me to regenerate it for a new file.

---

## Editing the content

Everything editable sits in one block at the top of the `<script>` in
`index.html`, under **`1. CONTENT`**:

- **`ECHOES`** — the three Echoes: titles, intro line, who left them, the text of
  the two student memories.
- **`ROUTES`** — which Echo each curiosity path returns.
- **`CHAPTERS`** — the era labels that appear during playback.
- **`ECHO_COUNT`** — the mocked 143 on the *Echo left* screen.
- **`TRANSCRIPT`** — the script behind the **CC** button.

---

## Known limitations — worth stating in your write-up

1. **The film and the audio are different recordings.** Different narration,
   different sound design, 95 seconds apart in length. So a participant preferring
   one is telling you something about *these two productions*, not cleanly about
   medium. Asking them *why* is what rescues this — the reasons will usually make
   clear whether they're responding to the medium or to the edit.
2. **The era labels during playback are approximate.** They're proportional
   placements from the §21 timeline, scaled to each track, never checked against
   the actual narration. The tester panel shows a live timecode — watch it once
   through and correct the `CHAPTERS` values in `index.html`.
3. **Captions aren't time-synced.** The **CC** panel shows the written §16 script
   as a readable transcript, so §43's transcript requirement is met, but words
   don't highlight as they're spoken and the wording may drift from what's said.
4. **The 143 counter is mocked** and doesn't move between participants (§29).
5. **Echoes aren't stored or shown to anyone.** Nothing a participant leaves is
   published, per §25 — it's captured for you and that's all.
6. **Data is per machine.** The CSV lives in that browser on that laptop. Testing
   on two devices means two exports.

---

## Test-day checklist

- [ ] Unzip the folder somewhere stable; open `index.html` once and confirm the film plays
- [ ] Allow microphone access once, before the first participant
- [ ] Check the volume — headphones or a small speaker in the pod
- [ ] Bookmark `index.html#responses` so your data is one click away
- [ ] Open the tester panel, **Clear** old data, close the panel
- [ ] Put the browser in fullscreen (**F11**, or **Ctrl/Cmd + Shift + F**) so no address bar shows
- [ ] Echo cards in the tray, signage outside the pod
- [ ] Between participants: **Start over** (top right, tap twice)
- [ ] At the end of the day: **Download CSV** and **Download all** recordings

Opening line, per §38 — don't explain anything beyond this:

> *"Imagine you're walking past this at UQ Lakes. Take a look and interact with it
> however you naturally would."*
