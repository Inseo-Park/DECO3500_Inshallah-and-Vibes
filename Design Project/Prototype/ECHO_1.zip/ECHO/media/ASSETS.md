# ECHO — media assets

Everything the prototype loads lives in this folder. Swap any file for a
same-named replacement and the prototype picks it up — no code changes needed.

## Story media (Echo #027 — "The University That Wouldn't Stay Quiet")

| File | What it is | Specs |
|---|---|---|
| `echo-027-video.mp4` | **Mode A** — the illustrated archival documentary | 1920×1080, 30fps, 3:57, 95 MB, faststart-optimised for instant seeking |
| `echo-027-video-light.mp4` | Mode A fallback if the pod tablet stutters | 1280×720, 3:57, 23 MB |
| `echo-027-audio.mp3` | **Mode B** — the immersive audio documentary | 192 kbps stereo, 5:32, 7.6 MB |

**Note on the A/B comparison:** these two tracks are different recordings —
different narration, different sound design, 95 seconds apart in length. The
prototype logs which mode each participant saw so the difference can be
reported as a stated limitation rather than treated as a clean medium test.

## Stills

| File | Used on | Source |
|---|---|---|
| `echo-027-still-modeb.jpg` | Mode B's single archival still | 0:52 — the 1967 sit-down: students seated with linked arms facing a line of police |
| `landing-greatcourt.jpg` | Landing screen ground, heavily dimmed under the type | 0:14 — students talking in the Great Court cloisters, jacaranda in bloom |
| `echo-027-poster.jpg` | Echo card / story intro plate | 0:02 — the title card |
| `end-greatcourt.jpg` | End screen | 3:52 — the closing Great Court illustration |

## Palette (sampled from the video's own title card)

The interface colours are pulled from the film so the story and the UI read as
one object rather than a video embedded in an unrelated website.

| Token | Hex | Contrast on paper | Use |
|---|---|---|---|
| `--paper` | `#F4E6CB` | — | page ground |
| `--paper-deep` | `#EBD9B8` | — | cards, recessed panels |
| `--ink` | `#221C17` | 13.66:1 | body and display text |
| `--ink-soft` | `#5A4C42` | 6.68:1 | secondary text |
| `--maroon` | `#6E1C20` | 9.20:1 | primary accent, buttons, Echo numbering |
| `--rust` | `#A85C3C` | 4.00:1 | **large text only** (24px+) and accents |
| `--tan` | `#C99B74` | 2.02:1 | **decorative only** — rules, borders, grain |

All body text uses `--ink`, `--ink-soft` or `--maroon`, each of which clears
WCAG AA and AAA for normal text. `--rust` and `--tan` never carry meaning on
their own.
