# ECHO v19 — nothing changes the page any more

Written before building, as always.

Your note this round is mostly one complaint said nine ways: **the prototype
keeps throwing you out of where you were.** You tap a thread inside the UQ
Lakes panel and the whole screen becomes a thread page, and now the lake is
gone and you have to walk back and find it again. That is the thing being
fixed, and it is fixed in one place so it is fixed everywhere.

Nine items.

---

## 1. The panel is the page now

**Now:** the place panel and the tree panel list things, and tapping one of
them calls the router and replaces the screen.

**Change:** those panels get their own little history. Tapping a thread inside
a panel **turns that panel into the thread** — the whole thread, every Echo in
it, every reply under every Echo, the hearts, the composer at the bottom — with
**← back** in its header that returns you to the list you came from. You never
leave the garden, your character never moves, the camera never jumps.

Concretely, every panel in the garden is now a **stack**:

```
UQ Lakes          →   « The eel nobody has photographed »   →   one Echo + its replies
(49 Echoes)           (the whole thread, in the panel)          (the branch under it)
  ← back to walking     ← UQ Lakes                               ← the thread
```

The back button always names the thing it goes back to, so you always know
what tapping it costs you. At the bottom of the stack it reads **← Back to
walking** and closes the panel, leaving you exactly where you were standing.

This applies to:

- **the five place panels** — their Echo lists, and the thread each Echo sits in;
- **anybody's tree** — their Echoes list, one of their Echoes, and
  **Open the whole thread**, which from now on opens the thread *in the right-hand
  panel* instead of navigating. You see the full conversation: the opening Echo,
  everything people added, nested replies, all of it, scrollable, in the panel.
- **your own tree** — the same, plus alerts and saves.

The panel gets wider for this, because a full thread needs room: **420 → 520px**
on a landscape screen, and on an iPad in portrait it is a bottom sheet that
**drags up to nearly full height** and back down. Content scrolls inside it; the
header with the back button stays put.

The old whole-screen thread page is still there and still works — it is what
Discover UQ opens into. It is simply no longer what a tap in the garden does.

---

## 2. Walking is how the garden starts

**Now:** you arrive looking down at the whole island, and walking is a button
you have to find.

**Change:** entering **UQ social garden** drops you straight into **walk mode**,
standing at your own tree, with the dpad under your left thumb and the camera
behind you. The first card of the walkthrough says so in one line — *you're the
one in purple; hold the pad to walk* — and the island view becomes the button
instead (**◉ Whole island**, top right), for when you want to see everything at
once.

So the default is the interactive thing, and the overview is the option.

---

## 3. The plaques open the place

**This was a real bug.** The landmarks were drawn into the ground layer as
decoration, and only the *proximity bubble* — the thing that appears when you
walk close enough — was ever clickable. So tapping "FORGAN SMITH" on screen hit
the world layer, the world layer read it as "walk to that tile", and the panel
never opened. You were doing the obvious thing and the prototype was ignoring
it.

**Change:**

- Every landmark gets a real **hit area over the whole building** and over its
  **name plate**, both tagged as chrome so the world stops swallowing the tap.
- Tapping either one **opens the place panel immediately**, from anywhere on the
  island, whether you are standing next to it or across the water.
- Tapping it from far away **walks your character there** while the panel opens,
  so the two things agree with each other.
- The plate lifts and the building outlines on hover/press, so it looks like
  something you can tap before you tap it.
- The proximity bubble stays — walking up to a place still offers it — but it is
  no longer the only way in.

Same treatment for **trees**: the trunk, the canopy and the name plate are all
one hit area.

---

## 4. Edit and Delete go under ⋯

Two buttons sitting on every one of your own Echoes is clutter, and it marks
your posts out as different-looking rather than just yours.

**Change:** a single **⋯** sits at the end of the meta row on your own Echoes.
Tapping it opens a small menu under it with **Edit** and **Delete**. Tapping
anywhere else, or pressing Escape, closes it. Delete still asks once before it
does anything, and still tells you how many replies will go with it.

Everywhere an Echo of yours appears: the thread page, the panel thread view, the
reel drawer, the board, a flower in the garden.

---

## 5. The conversation panel, rebuilt

**What you saw:** a big blob of a dot, and underlined dots. Both are real.

- The blob is the little coloured dot that marks who is speaking. It was
  positioned absolutely at a fixed size, so when a line wrapped — or when the
  panel was narrow — it escaped its row and sat over the text at the wrong
  scale.
- The underline is inherited: the lines sit inside a container that styles
  anything inline as a link, so the dot picked up a text-decoration it was never
  meant to have.

**Change:** the whole chat is rebuilt rather than patched.

- **Bigger panel** — you asked, and a conversation needs it. It is now the same
  520px / tall-sheet as everything else.
- Each line is a **proper message row**: the speaker's little blocky face at the
  left, their handle above the words, the words in a rounded bubble. Yours are
  purple and on the right; theirs are paper-coloured and on the left. No loose
  dots anywhere, nothing absolutely positioned, nothing inheriting link styles.
- **Who's in the conversation** sits across the top as a row of faces with
  handles under them, and a *leave* on the right.
- Someone joining is a **centred hairline notice**, not a floating italic line.
- The openers still fold away after a few lines into **⋯ prompts**.
- *Simulated for this prototype* sits in one quiet line along the bottom edge.
- Typing area is one row: a box and a **send** arrow.

---

## 6. The landmarks become buildings

**Now:** three or four bricks and a sign. Fair.

**Change:** each of the five is built properly, out of the same cubes, at a size
you can actually walk up to and around. Roughly four to six times the block
count each, and each one made of parts that read as architecture:

| | What gets built |
|---|---|
| **Forgan Smith** | A long sandstone façade — a colonnade of **nine two-storey arches**, a rhythm of windows above them, the **clock tower** rising three storeys over the centre with a clock face and a copper-green roof, the **tunnel arch** cut through underneath, and the wide front steps |
| **The Great Court** | A **closed sandstone cloister** — arched walks on all four visible sides, carved grotesque blocks along the parapet, the lawn inside, jacarandas at the corners, the graduation steps with a dais |
| **Duhig Library** | A **five-storey block** with a grid of lit and unlit windows, a glazed ground-floor entry with a revolving door, a concrete brow over the top, the steps, bike racks, and someone's bike left against the wall |
| **The Lakes** | A real body of **layered water** with a shore, reeds, lily pads, a **timber boardwalk out over it**, two benches, a willow, and the ibis standing about on the grass |
| **The Ferry Terminal** | A **pontoon and gangway** out over the river, a roofed shelter with a bench and a timetable board, railings, bollards, and a **CityCat** at the dock with windows, a cabin and a wake |

Each one casts a shadow, sorts correctly against the characters walking past it,
and has its own small ambient motion (the clock hand, water glint, the ferry
rocking) that stops dead under reduced motion.

Nothing here is traced from a photograph or from anyone's asset pack — they are
original blocky interpretations built in code, which is also what makes them
free to use in your submission.

---

## 7. Everything in Discover UQ opens

**Now:** a lot of the newer Echoes are text-only, so tapping one that claims to
be a photo or a film gets you *no media*. That is my fault — the content round
added 305 Echoes and none of them had anything attached.

**Change:** media across the whole archive, generated into the build:

- **Photographs** — generated pixel scenes, in the same visual family as the
  garden: sandstone colonnades, a lake at dusk, a crowded refectory queue, a
  noticeboard, a protest on the steps, a lecture theatre, jacaranda over a path,
  a desk at 3am. Sixteen of them, assigned to Echoes whose words match.
- **Voice notes** — a real playable tone track with a drawn waveform, a
  duration, and a **transcript** underneath, so a voice Echo has something to
  read as well as hear.
- **Film** — short generated clips (the blocky scenes, animated: petals falling,
  water moving, a crowd on the steps) with a poster frame, a play control and a
  scrub bar.
- Every Echo that says it is a photo, a voice note or a film **has one**, and
  every tile in every theme, every "more in this subject" row, every reel slide
  and every tile on the board opens into something. Nothing reports *no media*
  anywhere.

And it is all labelled: a small **simulated** mark sits on every generated
photo, clip and voice note, because none of it is a real recording of a real
place or person.

---

## 8. The three tiles stop looking the same

**Now:** three dark panels of the same size with the same sandstone-ish shapes
on them, so the eye has nothing to catch.

**Change:** three scenes that could not be mistaken for each other — different
palettes, different compositions, **people in all three**, and motion that says
what the thing does:

- **Discover UQ — the archive.** Warm amber interior. A tall wall of **shelved
  boxes and bound volumes**, a card-catalogue drawer pulled out, and **two
  figures**: one up a small ladder reaching for a box, one below holding an open
  folder, turning a page. Dust drifts across the light. Motion: the page turns,
  the ladder figure reaches, light moves.
- **UQ social garden — the island.** Daylight greens and purples. Three blocky
  trees in flower on a slice of island with the water edge showing, **four
  people** walking the path between them, one standing at a tree with a flower
  opening over their head, a bird crossing. Motion: people walk, the flower
  opens and closes, petals fall, the bird crosses.
- **Share something — leaving one.** Dusk purple. **Two figures facing each
  other** close up, one holding up a glowing flower and handing it over, the
  other's speech bubble filling with three dots and then a word. A third figure
  walks in from the edge. Motion: the flower passes between them, the bubble
  types, the flower lands and lights up.

Each tile is taller, carries its title and a one-line *what this is* over a
gradient at the bottom, and they stack on an iPad in portrait. All three freeze
under reduced motion.

---

## 9. The glitch pass

Everything above, then a sweep for the rest:

- Every new control registered as chrome, so **no tap is ever swallowed** by the
  world layer — this is the class of bug that broke Forgan Smith and it gets a
  single audited list rather than ad-hoc additions.
- No absolutely-positioned decoration inside flowing text anywhere.
- No inherited link styling on anything that isn't a link.
- Panel scroll position remembered per level of the stack, so going back
  returns you to where you were in the list, not to the top of it.
- The composer inside a panel thread posts into that thread and the panel
  repaints in place.
- Walk mode survives everything: opening a place, reading a thread in the panel,
  having a conversation, going into a tree and out again.
- Tested with **real taps** at 768×1024, 820×1180 and 834×1112 portrait, plus
  two landscape sizes, on every path above.

---

## What stays

Discover, threads, filters, the composer, Reel, Share, the board, profiles, the
demo account and its alerts, the trees that grow with the person, the flag on
your tree, ⚑ My tree, the pod map, group conversations, the flower animation.

## Still simulated, and labelled

The sixteen people and everything they say alone or in a group; the demo
account; the pod map and its numbers; and now also every photograph, voice note
and film in the archive — all generated by the app, none of it a recording of
anywhere real, and each one marked.
