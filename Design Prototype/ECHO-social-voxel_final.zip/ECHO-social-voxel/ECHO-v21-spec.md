# ECHO v21 — real history, and the pages that were letting it down

Written before building. Research done first this time, because most of this
round is content.

Seven things.

---

## 1. The walkthrough starts at 1 of 4. Every time.

**What you saw:** it opens on **4 of 4**, and once dismissed it never comes
back.

**Why, exactly:** the cards are advanced by whatever you do, not in sequence.
`coach(4)` fires when you walk into a tree, `coach(2)` when you drag. If card 1
is on screen and you tap a tree, the code jumps straight to 4 and the middle two
are skipped forever. Separately, "seen it" was written to local storage, so a
reload never showed it again.

**Fix:** two lines.

- The walkthrough can only ever advance **one card at a time**, whatever
  triggers it. Tap a tree on card 1 and you get card 2, not card 4.
- "Seen it" is now **per session, not per device**, so every fresh load of the
  prototype starts at **1 of 4** — which is what you want when you're handing an
  iPad to someone in a crit.

---

## 2. Share something, rebuilt

**What you saw:** a text box pinned to the left, a title field floating under
it, a mile of empty paper, and a full-bleed button welded to the bottom of the
window. Everything else in the prototype is centred, warm and alive and that
page is a form.

**Fix:** a proper composition, centred, at a readable measure:

- An **illustrated header** — the same blocky dusk scene as the Share door, as a
  banner across the top, so the page belongs to the rest of the thing.
- One **card** in the middle of the page, maximum 640px wide, centred, with a
  shadow and the purple top rule every other card has.
- Inside it: the **prompt** (*Say the thing…*), a bigger, warmer text area that
  **grows as you type**, the live counter, then the three attachments as proper
  **tiles with icons**, not pill buttons in a row.
- **Title** moves inside the card, optional, quieter, under a hairline.
- **Leave it →** becomes a normal-width button in the card, not a bar across the
  bottom of the browser.
- A line under the card that says where it will go — *the pod reads the words
  and files it; you can move it afterwards* — so the page explains itself.
- And a strip of **three prompts** you can tap if you're stuck: *Something that
  happened here · Somewhere you keep going back to · Something you were never
  told*. They drop into the box.

Same on the iPad: the card centres, the banner shortens, nothing is pinned to
the window.

---

## 3. Real history, researched

This is the main piece. I researched UQ St Lucia properly — UQ's own history
pages, *Carving a History*, UQ Library and Fryer, the Queensland Heritage
Register entry, the Australian Dictionary of Biography, Queensland State
Archives, the Australian War Memorial, the Bureau of Meteorology, eBird. **Every
historical claim in the build now carries a source**, and where sources disagree
the build says so rather than picking one.

### The five places get a **History** tab

Each landmark panel gets two tabs: **Echoes** (what people left) and
**History** (what is actually documented). The History tab is four cards:

**The Great Court**
- Built in stages over roughly forty years: foundation stone laid by Premier
  William Forgan Smith on 6 March 1937, construction from March 1938, work
  proceeding clockwise around the court for financial reasons, and the colonnade
  between Michie and Goddard finally closing the ring in March 1979.
- Clad in **Helidon freestone** quarried near Toowoomba. Unusually, no uniform
  colour was asked for — the stone runs purple, lavender, cream, buff and brown,
  and is most vivid when wet.
- **Over 1,200 carvings.** John Theodore Muller, University Sculptor from 1939,
  carved most of the statues and friezes and 32 of the 50 grotesques before his
  death in 1953; carving then stopped for about two decades. Rhyl Hinwood won a
  1976 Senate competition and has been University Sculptor since. The 50th and
  final grotesque — Margaret Valadian AO MBE, the first Indigenous Australian to
  graduate from UQ — was unveiled on 24 October 2025.
- The odd details, because they are the good ones: the Jurassic frieze is carved
  from stone roughly the same age as the animals on it; the Tasmanian devil was
  never a Queensland animal; a grotesque of John Michie shows him putting the
  shot with incorrect technique; most pre-1953 carving records were lost in a
  house fire.
- On the Queensland Heritage Register since 8 March 2002, described as the
  clearest intact Australian example of a university laid out on Jeffersonian
  "academic village" principles.

**Forgan Smith**
- Named for **William Forgan Smith**, Queensland Premier 1932–1942, who
  announced the state would build at St Lucia and laid the foundation stone. He
  later joined the UQ Senate and became Chancellor in 1944.
- Requisitioned during the war: from **1 August 1942** the site was **Advanced
  Land Headquarters** of the Allied Land Forces under General Sir Thomas Blamey.
  A Battle Room in the basement, 360 staff, the Australian Women's Army Service
  running communications, planning for Kokoda, Buna, Gona, Lae and Madang. The
  Commonwealth paid £15,000 a year. A commemorative plaque was presented in 1945
  and is in the tower.
- Officially opened by Premier Ned Hanlon in **May 1949**, a decade after
  construction began. Law moved in in 1948.
- **The tunnel is not what people think.** The documented tunnels are service
  ducts under the Great Court carrying power, water and data — confined spaces,
  closed to the public, with peepholes around campus marking the entrances. The
  build says this, and then says that the stories are doing something else.

**Duhig**
- Named for **James Duhig**, Catholic Archbishop of Brisbane from 1917 to his
  death in 1965, a member of the UQ Senate for nearly fifty years and the founder
  of St Leo's College. The only Great Court building not named after an early
  professor.
- The Library moved in in late 1948. Three floors were added in the mid-sixties
  to designs by **James Birrell**. The Central Library by **Robin Gibson** opened
  in May 1973. Refurbished by Wilson Architects in 1998 and again in 2018–19.
- **Duhig Tower holds the Fryer Library**, founded 1927, through the F.W.
  Robinson Reading Room — and Robinson, who founded it, is himself one of the
  grotesques in the Court outside.

**The UQ Lakes**
- Made by damming the flow of **Carmody Creek**; UQ dates it to the late 1940s
  or early 1950s, though pines were planted "around the lake" from March 1939,
  so the sources don't quite agree and the build says so.
- It irrigates the Great Court and the playing fields. The Effluent Lakes were
  added in the 1980s with the golf club and the City Council.
- **What actually lives in it**, documented when the lake was drained for the
  2022 renewal: more than 650 native fish and **251 turtles** relocated,
  including **541 long-finned eels**, bony bream, sea mullet, eel-tailed catfish
  — and a single **Queensland lungfish**, 127 cm long, an endangered species,
  moved to Roma Street Parklands.
- The birds are real and countable: the eBird hotspot for UQ Lakes lists 33
  species in a single month — Australian brushturkey, Australian ibis, rainbow
  lorikeets, dusky moorhens, little corellas, an Australasian darter, a tawny
  frogmouth, a Brahminy kite. Eastern water dragons are documented here too.

**The Ferry Terminal**
- The campus sits inside a bend of the river, with **St Lucia Reach** to the
  north and **Cemetery Reach** to the east; the easternmost point is called
  **The Elbow**.
- The old terminal was **destroyed in the January 2011 flood**. A temporary
  wharf opened that April; the permanent one opened on **25 May 2015**, 450
  metres upstream.
- **The floods, with the actual numbers.** The river at the Brisbane City gauge:
  8.35 m in 1893, **5.45 m in January 1974**, **4.46 m on 13 January 2011**,
  3.85 m in February 2022. In 2011 most teaching buildings sat above the line;
  what went under was the pool, the tennis courts, the playing fields, two
  childcare centres and International House. Staff shifted almost 300 tonnes of
  silt off St Lucia roads in a day, and campus reopened on 20 January.

Each card carries its source, and the tab footer links out to the UQ, Heritage
Register, Fryer Library and State Library pages the facts came from.

### A documented layer in the threads

Alongside the invented student Echoes, the archive now carries **about forty
real entries** — marked **ARCHIVE**, in a different card, each with its source
and date, and each filterable with the existing *archive only* filter:

- the 1967 civil liberties march: around four thousand people, the sit-down in
  Roma Street, and the arrest count given honestly as *114, with some sources
  saying 120 or 144*;
- the 1977 ban on street marches and the 418 people arrested in Brisbane on
  22 October;
- the 1985 protest of about five thousand at Mayne Hall over the honorary
  doctorate — and the fact that UQ's own records disagree about whether it was
  awarded in 1984 or 1985;
- 4ZZZ's first broadcast on 8 December 1975 from the Union Complex, the first
  track played, the eviction in December 1988 and the move to Toowong in July
  1989;
- Merle Thornton and Rosalie Bognor chaining themselves to the bar of the
  Regatta Hotel in 1965, and the law changing that year;
- *Semper Floreat*, founded 1932, still going;
- the Schonell Theatre, built 1970, named for Vice-Chancellor Sir Fred Schonell;
- Mayne Hall, opened 31 March 1973, reopened as the UQ Art Museum in April 2004;
- the Maynes' 1926 gift that bought the site, and what was there before —
  farmland, a sugar mill that ran until the 1893 flood;
- Ernest Bick, who raised and planted **more than 130 jacarandas** on this
  campus in the 1940s and died in 1949 while planting at the Women's College
  site; the trees on campus traced back to the 1864 jacaranda in the Botanic
  Gardens, blown down in 1980;
- the Lady MacGregor fig planted in 1909, the Bodhi tree planted during the
  Dalai Lama's 1981 visit, and the cutting of the Barcaldine Tree of Knowledge;
- Joseph Croft, first known Indigenous student to enrol at UQ, in 1944;
  Margaret Valadian, first known Indigenous graduate, in 1966; the Aboriginal
  and Torres Strait Islander Studies Unit from its 1984 Enclave Program to its
  formal amalgamation in 1987.

### What the research found about Country, and what the build now says

I went looking for UQ's Acknowledgement so the prototype could name the
Traditional Owners of this campus properly. **UQ's published Acknowledgement
names no peoples** — not on its reconciliation pages, not in its Stretch
Reconciliation Action Plan. The RAP itself contains a commitment to produce a
protocol document "identifying Traditional Owners on all UQ campuses and sites",
which means UQ treats this as **not yet done**.

So the notice card in *The ground it stands on* stays, and gets sharper: it now
states that finding, with the source, and reproduces UQ's actual Acknowledgement
wording. It also carries the one river name that is verifiable from a Queensland
Government source — **Maiwar**, which the Queensland Redistribution Commission
describes as "a word used by some Aboriginal people to refer to the Brisbane
River" — with that hedge intact, because the Commission does not attribute it to
a language group.

That is a stronger, more defensible position for your submission than a named
Acknowledgement I could not source, and it points at exactly the piece of work
that has to happen next.

---

## 4. The photographs

You asked for real photographs instead of generated ones, and gave permission to
take them from open sources. I did the research. **I could not download them:**
this environment's network proxy blocks Wikimedia outright, and I have no way
around that.

What you get instead, which gets you there in about ten minutes:

- **A verified list of 24 open-licensed photographs** of the campus —
  `PHOTO-CREDITS.md` in the folder — with, for each one: what it shows, the
  Commons page, the direct file URL, the exact licence, and the attribution
  string that licence requires. Thirteen are **public domain** (Queensland State
  Archives and State Library of Queensland construction photographs from 1937 to
  1948, an Australian Women's Army Service parade at St Lucia in 1943), two are
  CC BY, nine are CC BY-SA.
- **A one-command download script**, `get-photos.sh` (and `get-photos.ps1` for
  Windows), that fetches all of them into `media/photos/` with the right
  filenames.
- **The build already looks for them.** Every generated picture now checks for
  its real counterpart first — `media/photos/greatcourt.jpg`,
  `forgan-tower.jpg`, `lakes-boardwalk.jpg`, `construction-1940.jpg` and so on —
  and uses it if it's there, falling back to the generated art if it isn't. Run
  the script and the prototype fills with real photographs with no other change.
- **Credits are built in.** A **Picture credits** panel lists every photograph,
  its photographer and its licence, so the attribution requirement is met inside
  the prototype rather than in a footnote you have to remember.

Two things worth knowing before you run it: the share-alike licences (CC BY-SA)
are fine for *showing* a photograph with a credit, but if you composite or trace
one into a design asset, share-alike can oblige you to license that asset the
same way — so the public-domain thirteen are the safe ones for anything baked
into the UI. And one Commons file is mislabelled "St Lucia campus, ca. 1912";
UQ was at George Street until 1948, so the credits file flags it.

---

## 5. The pixel art stops being squares

Fair. The scenes are built from big flat rectangles, so they read as blocks
rather than as pixel art.

**Fix** — the same scenes, four times the density:

- **A real pixel grid.** Everything snaps to a 4px unit on a 480×300 canvas, so
  the detail is small and consistent rather than a few large shapes.
- **Dithering and shading.** Two-tone checkerboard dithering on every gradient —
  sky, water, stone, shadow — which is what makes pixel art read as pixel art
  rather than flat colour.
- **Outlines and highlights.** A darker edge on the shaded side of every solid,
  a lighter one-pixel lip on the lit side.
- **Texture.** Stone courses in the sandstone, grain in the timber, leaf clumps
  rather than leaf rectangles, ripples in the water, scanlines in the lit
  windows.
- **Denser figures.** People get a proper five-tone palette, hair with a
  highlight, a face at pixel scale, a bag or a cup, and a two-frame walk.
- **More in frame.** Each scene gains middle-ground and background layers, so
  there's depth rather than one plane of objects.

Same for the three door tiles, which get the same treatment plus a slow
parallax.

---

## 6. A home button

**⌂** in the top right of every screen you can deviate to — Discover, a thread,
the garden, the board, an Echo, Share. One tap back to the ECHO menu, from
anywhere, without hunting for the right back arrow.

---

## 7. What stays

Walking as the default, the panel stack, tappable landmarks and plaques, the
in-panel composer, the ⋯ menu, the rebuilt conversation panel, the five
buildings, the seventh theme and its notice.

## Honesty, unchanged

Student Echoes are invented and labelled. Generated pictures are marked
**simulated**. Historical entries are marked **archive** and carry a source. No
Aboriginal or Torres Strait Islander stories, names, language or cultural
knowledge are invented anywhere in this build. Where the sources disagree — and
on several of these they do — the prototype says so instead of choosing.
