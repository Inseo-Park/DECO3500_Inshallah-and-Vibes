# ECHO v17 — the living garden

Written before building. From here on there is **one build**: the block garden.
The painted version is retired, because the pixel one is what tested well.

Nine changes.

---

## 0. Already there (from last round)

**Editing and deleting your own Echoes is already in.** Every Echo you left
carries **Edit** and **Delete** beside its heart; nobody else's does. Edit opens
the words in place and marks the card *edited*; Delete asks once, then takes the
Echo and everything added to it. It works on the thread page, in the reel's
reply drawer, on the board and on a flower in the garden, and survives closing
the pod. If it isn't showing, the build being tested is the one before last.

---

## 1. The white square behind an open flower

That is a real bug and I know what it is. Every flower has a soft "glow" shape
behind it that is invisible until the flower opens. In the block build it was
drawn as a **rectangle filled with the species' bloom colour** — and for the
pale species (paperbark, gum) that colour is nearly white. Opening the flower
scales the whole group 2.7× and turns the glow fully opaque, so you get a large
cream rectangle sitting behind everything.

Fixed by making it a **soft ring behind the flower** rather than a filled
rectangle, capped well below full opacity, and scaled with the flower instead of
independently.

---

## 2. "Answer this…" becomes "Add to this…"

Testers were right — you don't *answer* an Echo. Every reply box now reads **Add
to this…**, and the button under an Echo stays **+ Add**, so the same two words
mean the same thing everywhere: in a thread, under an Echo, in the reel drawer
and on a flower.

---

## 3. UQ purple

The red becomes **UQ purple, #51247A** — the university's official brand colour
— and the whole system is rebuilt around it:

| | |
|---|---|
| `--uq` | `#51247A` — buttons, your tree, the active state of everything |
| `--uq-lift` | `#6B3496` — pressed and hover |
| `--uq-deep` | `#36164F` — the darkest purple, for plates and the night |
| `--gold` | `#E8B84B` — the one accent, for your own marker and the unread dot |
| paper, ink | unchanged — the warm sandstone background stays |

Purple does the work that maroon did; gold is used sparingly and only ever to
mean *this one is yours*.

---

## 4. The main menu becomes three big pictures

The three doors stop being list rows with emoji and become **three large
illustrated tiles**, each a small animated voxel scene drawn in the same blocks
as the garden:

- **Discover UQ** — a sandstone cloister: arches, columns, a jacaranda over the
  top of them, petals drifting down.
- **UQ social garden** — a slice of the island: three blocky trees in flower,
  two little characters walking between them, a bird crossing.
- **Share something** — two characters facing each other on a block of grass,
  one holding up a glowing flower, the other's speech bubble blinking.

They animate gently and continuously (drifting petals, walking characters,
blinking bubble), stop dead under *reduced motion*, and sit two-up on a wide
screen, stacked on an iPad in portrait.

---

## 5. A great deal more to find

Twenty-four new threads — four in every theme — and about three hundred new
Echoes, written for this prototype.

The point is that **Surprise me** has to actually surprise you. So the new
material is deliberately uneven in the way a real feed is: dry one-liners,
practical tips, arguments that run three replies deep and then someone concedes,
campus myths (the tunnel, the library cat, the eel nobody has photographed, who
keeps moving the traffic cone), people typing in lowercase at 3am in exam week,
and a few that land properly — the person who designed the flyers nobody kept,
the note left in a beanbag in Duhig, the photograph of somebody's grandfather in
the Great Court.

Running jokes cross between threads on purpose, so it reads as one community
rather than a list of entries.

Everything in it is written for this prototype. Nothing is taken from Reddit or
anywhere else, no real person is named, and nothing is a historical claim — they
are memories and opinions, the way the pod would actually collect them. The real
archive material stays separate and stays labelled.

---

## 6. The garden you can walk in

This is the big one. The garden gets **two views**, with one button between
them.

### Aerial — what exists now
The whole island at once. Drag to pan, pinch or buttons to zoom, tap a tree,
walk in.

### Walk — new
The camera drops behind **your own character**, a blocky figure in UQ purple
standing at your tree.

**Controls, on an iPad.** Three ways at once, because a pod gets used standing
up and one-handed:

1. A **four-way pad bottom-left**, under your left thumb. Hold to walk.
2. **Tap any ground tile** and your character walks there by itself.
3. **Arrow keys / WASD** if anything with a keyboard is ever plugged in.

The pad is the primary. Tap-to-walk is what people reach for anyway on a
touchscreen, so it is there too and costs nothing.

**What you can walk up to:**

- **A tree.** A bubble appears over it — *FIGTREE-30 · Walk in* — and tapping it
  opens that person's profile, exactly as the aerial view does.
- **A person.** The other people in the garden are blocky characters walking the
  paths between trees. Each one is actually somewhere: *reading WATTLE-18's
  tree*, *at the Great Court pod*, *just left something in "Jacaranda week"*.
  Stand near one and a bubble appears over their head — **Talk to them**.

### Talking to someone

Tapping the bubble opens a small panel beside them. You get:

- three **openers** to tap — *What brought you here?* · *What did you leave?* ·
  *Show me your tree*
- and a **box to type your own**.

They answer from what they have actually left. Ask what they left and they tell
you about a real Echo of theirs, with a button to go and read it. Ask about
their tree and the camera walks you to it. Type something of your own and they
answer in character, from a written repertoire — this is a prototype with no
network, so it is not a language model and not another real person, and the
panel says so in one line: *simulated for this prototype*.

Every conversation is listed afterwards in your profile's **Activity**, so the
loop stays visible.

---

## 7. The other pods, live

There are going to be five to seven of these installations around St Lucia. The
garden now shows that.

A chip sits in the top-left: **◉ 4 pods busy**. Tapping it opens a small
**campus map** — a blocky plan of St Lucia with a marker on every pod: Great
Court · Forgan Smith · Duhig Library · The Lakes · Union Complex · Advanced
Engineering · Ferry Terminal. Each marker shows how many people are at it right
now, and the one you are standing at is marked **you are here**.

The numbers drift every few seconds, people arrive and leave, and the characters
walking around your island are the people currently at *your* pod. Tap a marker
and you see what was last left there.

All of it is simulated — the pods are not connected to each other and there is
no server — and the map says so along its bottom edge.

---

## 8. The sidebar tiles, fixed

In the right-hand rail of a thread, the written Echoes were being squeezed into
tall thin cards with the text wrapping two words to a line. They become proper
rows: the quote at a readable width, the author and thread underneath, a hairline
between them — matching the rest of the system instead of fighting it.

---

## What stays

Discover, threads, filters, the composer, Reel, Share, the board, profiles, the
demo account and its alerts, edit and delete, the walkthrough, the flower
animation when you leave something.

## Still simulated, and labelled

The sixteen other people, their Echoes, saves, activity and replies; the demo
account; the people walking in the garden and everything they say; the pod map
and its numbers. Artwork is generated by the app from cubes and pixel squares —
no texture pack, no game's assets.
