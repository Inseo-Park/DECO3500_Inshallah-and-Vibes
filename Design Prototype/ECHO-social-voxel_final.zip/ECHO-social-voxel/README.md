# ECHO — v21

Built for an **iPad held in portrait**, and it fills a laptop screen too.
No internet, no account, no password.

```
ECHO-social-voxel/
  index.html                     ← open this
  README.md
  PHOTO-CREDITS.md               real photographs: licences and how to add them
  get-photos.sh / get-photos.ps1 one command to fetch them
  ECHO-v21-spec.md               what changed this round
  ECHO-v20-spec.md               the round before it
  ECHO-v19-fix-spec.md           the round before it
  ECHO-v18-garden-spec.md        the round before it
  ECHO-v17-living-garden-spec.md the round before it
  ECHO-v16-block-garden-spec.md  the round before it
  ECHO-v14-changes-spec.md       and the ones before those
  ECHO-v15-changes.md
  media/                         the archive films, voices and photos
```

## What's new in v21

**This round is mostly real history.** I researched UQ St Lucia properly — UQ's
own history pages and *Carving a History*, UQ Library and the Fryer, the
Queensland Heritage Register entry, the Australian Dictionary of Biography,
Queensland State Archives, the Australian War Memorial, the Bureau of
Meteorology, eBird. Every historical claim in the build now carries a source,
and where the sources disagree the build says so instead of picking one.

- **Each of the five places has a History tab** — four researched cards on how
  it was built, what it is made of, who it is named after, what happened in it
  and what lives in it, each with outbound sources.
- **Forty-one documented records** sit in the threads alongside the invented
  student Echoes, marked **ARCHIVE** and each linking to where the fact came
  from.
- **The walkthrough starts at 1 of 4**, advances one card at a time whatever you
  tap, and resets on every fresh load.
- **Share something is a page now**, not a form: an illustrated banner, one
  centred card, a text area that grows, attachment tiles, and three prompts to
  start from.
- **A home button** on every screen you can deviate to.
- **The pixel art is four times denser** — a real 4px grid, dithered skies,
  stone courses, timber grain, foliage that reads as canopy, and figures with a
  five-tone palette.
- **Real photographs can be dropped in** — see `PHOTO-CREDITS.md`.

## What was new in v20

- **The bubble goes away.** Opening a place used to leave *Look around* sitting
  over the grass offering you something you were already doing. It is now
  suppressed while anything is open.
- **Nothing takes you out of the garden. Nothing.** **Leave something here**
  opens a **box inside the panel** — write it, or attach a photo, a voice note
  or a clip — and posting files it, lands the flower on your tree and repaints
  the list with your Echo at the top, without the screen changing. The **+** in
  the corner does the same. The full-screen Share page is now only ever reached
  from the main menu.
- **An Echo left at a place belongs to that place**, whether or not it happens
  to use the word, so what you leave is there when you come back.
- **The ⋯ button** is three drawn dots instead of a character, so it sits
  centred in its circle rather than wherever the typeface put it.
- **An open flower has nothing drawn behind it.** The pale box is gone. The
  flower itself goes **deep UQ purple with gold corners and a cream centre**,
  and the block under it goes dark purple, so the one you are reading is the
  only thing on the tree that colour.
- **A seventh theme — The ground it stands on** (see below), and about **a
  hundred new Echoes**, most of them long ones with something to stop on.

## What was new in v19

**Nothing changes the page any more.** Everything you tap in the garden opens
*inside the panel beside you*, with a back button that names what it goes back
to. Tap a thread in the UQ Lakes and the panel becomes that thread — the whole
thing, every reply — and **← The UQ Lakes** brings the list back. You never
leave the island and your character never moves.

- **Walking is how the garden starts.** You arrive on your feet, pad under your
  thumb. **◉ Whole island** is the button now, instead of the other way round.
- **The plaques work.** Tapping a landmark or its name plate opens it from
  anywhere — that was a real bug: the landmarks were drawn as scenery, so only
  the proximity bubble was ever clickable and your tap was being read as
  "walk there". Trees and their plates are tappable the same way.
- **Edit and Delete** sit under a **⋯** on your own Echoes, not as two buttons.
- **The conversation panel is rebuilt** — proper message rows with a face, a
  handle and a bubble, in a panel half again as wide. The "big blob" was a 7px
  speaker dot that was inheriting the bubble's own styling; it's gone.
- **The five landmarks are buildings now**, four to six times the block count
  each: Forgan Smith's colonnade and clock tower, a closed cloister at the
  Great Court, a five-storey Duhig, a lake with a boardwalk over it, a ferry
  terminal with a canopy, a pontoon and a CityCat.
- **Everything in Discover UQ opens.** Every one of the forty-seven threads now
  has a photograph, a voice note and a film — all generated by the app and all
  marked as simulated.
- **The three doors are three different pictures**, with people in all of them.

---

## The shape

```
Intro grid → ECHO ID → MENU
   ├── Discover UQ   → People before us / What happened here / Surprise me
   │                   → straight into a thread
   │                   → UQ social garden
   ├── UQ social garden  → Garden (one tree per person) ⇄ Board (every Echo)
   └── Share something   → one screen → it becomes a flower on your tree
```

Top bar: **language only**. Your profile is your tree in the garden.

### The demo profile

The ID screen has a third choice: **Show me a full profile**. It signs you in
as **LAKEWALKER-07**:

- **eleven Echoes** across six subjects, including photos and a film;
- **other people's answers** sitting under six of them;
- **six saved threads**;
- **twenty-four alerts** — who liked what, who answered what, and what they
  said — four of them unread;
- likes spread across the archive and other people's Echoes.

It all comes back when you reopen the pod and tap **That's me, carry on**: the
account is rebuilt from the same seed, answers and alerts included, so the loop
you're demonstrating — leave something, come back, see what happened to it — is
there every time. The profile header marks it **demo**. The other two choices
still start empty.

The **menu** says so too: *UQ social garden · 4 new — people have answered or
liked yours.*

---

## Themes, threads, Echoes

- **Theme** — a big subject. Seven: Protest & politics · Music, radio & art ·
  Food & eating · Study & survival · Places & quiet · Life before us ·
  The ground it stands on.
- **Thread** — one story inside a theme. **Fifty-five** of them, carrying
  **four hundred and thirty-odd Echoes** — written for this prototype, uneven
  the way a real feed is: one-liners, arguments that run three replies deep,
  campus myths, people typing at 3am in exam week, and a few that land. Nothing
  in it is taken from anywhere else and no real person is named.
- **Echo** — one thing a person left: written, voice, photo or film. An Echo
  can answer another Echo, which is how a thread branches.

The colour throughout is **UQ purple, #51247A** — the university's own brand
colour — with a single gold accent that only ever means *this one is yours*.

**Comments are gone.** A reply is an Echo in any format, with its own heart,
its own answers and its own flower on the person's tree.

**Your own Echoes are yours.** Every one you left carries a **⋯** at the end of
its row — nobody else's does — and that opens **Edit** and **Delete**. Edit
opens the words in place and marks the card *edited* afterwards. Delete asks once, then takes the
Echo and everything people added to it. Both work on the thread page, in the
reel's reply drawer, on the board and on a flower in the garden, and both
survive closing the pod.

---

## The thread page

The top row is three things and nothing else:

**search field · Filters · +**

- **Filters** opens a row of chips *in place*, under the search field. Format
  (film / voice / written / photo), source (**everything · what people left ·
  archive only**) and when (last 7 days, this year, before 2000). Tapping a
  chip applies immediately — the Echoes repaint, the page doesn't jump, you
  keep your place. The button carries a number when anything is on, and a
  **Clear** chip appears at the end of the row.
- The **+** starts a new thread. Press it and it tells you so before it opens.
- A **theme strip** underneath, to jump sideways to another subject.
- **List ⇄ Reel** — the same thread as a page or as the full-screen swipe feed.

On a wide screen the thread is **two columns** — the Echoes and the composer on
the left, the rails on the right. On an iPad in portrait it is one column.

At the end of every thread: a **composer that is always there** (write, or
attach a photo, a voice recording or a clip, and Post — it appears in the
thread, you don't go anywhere), **More in <subject>** — topped up from
elsewhere if that subject is thin, so it is never a dead end — and **Echoes
people left near this**, four tiles into nearby conversations.

**+ Add** on any individual Echo opens the same box directly under it.

Starting a **thread** is one screen: a name, an optional line about it, and the
same composer. The thread comes into being the moment you post the first Echo.
Starting a whole new **subject** sits behind the researcher key (press and hold
the dot on the menu or end screen).

Every confirmation names both levels — *Added — Food & eating → The queue at
the sushi place* — so you always know where a thing landed.

---

## Sharing, and the flower

Share something is **one screen**: a text box, and **Photo · Voice · Film**
underneath it like an email's attachments. Write, or attach, or both. The
format is whatever you actually did. One button: **Leave it →**.

Then the moment that matters: the card you just made **shrinks into a flower,
travels down to your tree, lands on a branch** and opens, petals scattering,
with *Added to the UQ social garden · It's a flower on your tree.* You're told
where it was filed, with **Move it** if the pod guessed wrong, and that you'll
hear when someone adds to it.

Posting from the thread composer keeps you where you are and confirms the same
thing in a line at the bottom of the screen, with a way through to the garden.

### Filing without asking

The pod reads the words and files the Echo into a theme and a thread
**silently**. This is word-matching against each theme's vocabulary, written
into the app. It is not a model and there is no network: say that plainly if
anyone asks in a demo.

---

## The UQ social garden

**This version draws the garden out of blocks.** An isometric island of cube
tiles, grass, water and a dirt path; every person is a blocky tree with a
visible trunk and a cube canopy; every Echo is a **pixel flower** sitting on
top of it. The name of whoever's tree it is sits on a plate under each one.

The point of the change is navigation: the camera opens on **the whole island
at once**, every tree standing on its own tile with a dirt path joining it to
its neighbours, so nothing is hidden behind anything. Drag to walk, pinch or
use the buttons to zoom, tap a tree for its card, walk in. **◉** returns to
the whole island; **⚑** takes you home to your own tree from anywhere.

### Finding yourself

Your tree flies a **maroon banner** with a lantern at its base, stands in a
lighter clearing, and its name plate is maroon with a gold bar reading
**· YOU**. Everyone else's is plain.

### Trees grow with the person

How grown a tree is comes from everything that person has done — Echoes left,
answers received, hearts, and threads followed. A first-year with one Echo is
a **sapling**: one block of trunk and a single flower. Five years of leaving
things is an **old tree**: a thick 2×2 trunk, two side branches, roots at the
base, a wide canopy and petals on the ground around it. You can tell them
apart from across the island without reading a name.

### Walking in it

**Walking is the default.** Entering the garden drops the camera behind your
own blocky figure, standing at your tree. Three ways to move, all live at
once: a **four-way pad bottom-left** under your thumb, **tap any ground** to
walk there, and **arrow keys / WASD** if a keyboard is attached.

**◉ Whole island** in the corner is the other view — the whole thing at once,
drag to pan, pinch to zoom — and the same button walks you back.

**You can tap what you can see.** A tree, its name plate, a landmark or its
plaque all open straight away, whether you're standing next to them or across
the water; tapping something far off walks you there while it opens.

Going into a tree **suspends** the walk rather than ending it: you come back
out standing where you were, facing the same way, and the back button says
**← Back to walking** while you're inside.

### The people

Each of the sixteen is a proper little figure — a head with a face that turns
with them, hair in five shapes and six colours, a shirt with a collar and a
belt, arms that swing, legs that alternate, and one thing that's theirs: a
backpack, a tote, headphones, a coffee, a skateboard. The combination is fixed
to the ID, so you start recognising people. Yours is in UQ purple with a gold
band.

Everything is drawn by the app out of cubes and pixels. It isn't Lego's
minifigure or anyone else's character design — those belong to them.

### Talking, and groups

Walk up to somebody and they stop, with a bubble: **Talk to them**. You get
three openers — *What brought you here? · What did you leave? · Show me your
tree* — and a box to type your own. Ask what they left and they quote a real
Echo of theirs with a button to go and read it.

Once three or four things have been said the openers **fold away** into a **⋯**
button and the conversation gets the room back.

Each line is a proper message row — the speaker's little blocky face, their
handle, and the words in a bubble; yours purple and on the right, theirs on the
left. Somebody joining is a quiet hairline notice across the middle.

And it grows. Anyone walking within earshot drifts over and joins —
*MANGO-31 wandered over* — up to four people, shown as a row of faces at the
top. From then on they answer each other as well as you. **Leave** ends it for
you; they carry on and wander off.

All of it is written into the app. There is no network and no language model,
and the panel says so.

### Five places you can walk into

The island is a small map of St Lucia with five landmarks, each built properly
out of the same cubes as everything else:

| | What's there |
|---|---|
| **The Great Court** | A closed sandstone cloister: arched walks on all four sides, carved blocks along the parapet, corner towers, the lawn with its mown stripes, the graduation steps and a dais, jacarandas in the corners |
| **Forgan Smith** | A long colonnade of two-storey arches with a rhythm of windows above them, a three-block-wide **clock tower** with a clock face and a copper roof, the **tunnel arch** cut through underneath, and the wide front steps |
| **Duhig Library** | Five storeys with a grid of windows, some of them lit, a glazed ground floor with a revolving door, a concrete brow over the top, steps, bike racks and somebody's bike |
| **The UQ Lakes** | Layered water with a sand shore and reeds, a **timber boardwalk on posts** out across it to a viewing platform, benches, a willow, lily pads, and the birds that run the place |
| **The Ferry Terminal** | A waiting area under a steel canopy with a bench and a timetable board, a gangway and a railed **pontoon** out over the river, bollards, and a **CityCat** at the dock, rocking |

**Tap the building, or tap its plaque** — either opens the place from anywhere
on the island. Walking up to one still offers **Look around** as well.

Inside: **every Echo anyone has left about that place**, found by matching the
words people actually used against all four hundred and thirty-odd. Tap one and
the panel becomes that whole thread, scrolled to that Echo, with **← The UQ
Lakes** to get back to the list. **Leave something here** opens the composer
already filed to the thread that fits. The Lakes has forty-nine; the Great
Court twenty-nine.

### The other pods

A chip in the top-left reads **◉ 4 of 7 pods busy**. Tapping it opens a blocky
plan of St Lucia with every installation marked — Great Court · Forgan Smith ·
Duhig · The Lakes · Union Complex · Advanced Engineering · Ferry Terminal —
showing how many people are at each right now, and which one you're standing
at. The numbers drift; the people walking round your island are the ones at
your pod. Simulated, and the map says so.

### The walkthrough

Four cards: *you're the one in purple, hold the pad to walk* · *tap anything —
a tree, a landmark, a plaque, a person* · *the tree with the flag is yours*,
with a **Walk in** button · *everything opens in the panel, and ← goes back one
step without taking you off the island*. **Next** and **Skip** on every card,
and **?** replays it.

Leaving something runs the same moment as before, in blocks: the card shrinks
into a **pixel flower**, drops onto your cube canopy and opens.

Everything else — Discover, threads, filters, the composer, Reel, the board,
the profiles, the demo account — is identical to the other build. Only the
garden is drawn differently.

The artwork is drawn by the app itself: cubes, plates and pixel squares
generated in code. It is not anybody's texture pack, and no game's assets are
used or included.

**One tree is one person.** Drag to walk, pinch or use the buttons to zoom, tap
a tree for its card, walk in.

A compact **search field** sits in the top right, with the **+** beside it.

Walking in opens that person's **profile**. On a wide screen it **docks to the
right** and the camera recentres the tree into the space left over; on an iPad
in portrait it comes up as a bottom sheet. Either way it stays in step with the
tree:

- A header — the ID, the species of their tree, and **Echoes left · answers
  received · threads followed**, plus what they're reading now.
- **Echoes** — everything that person left. Tap one and its flower opens on the
  tree while the panel becomes that Echo and the conversation under it.
- **Saved** — the threads they follow, and whether they've added to them. This
  works on other people's trees too, not only your own.
- **Activity** — one line per thing done, newest first: left an Echo in «…» ·
  added to someone's Echo · liked a film in «…» · followed «…». Every line is
  tappable and lands where it happened.
- **Alerts** (yours only) — when someone adds to or likes something of yours.

**Activity and Alerts are yours alone.** Other people's trees show two tabs:
their Echoes and what they follow.

Opening an Echo — on a branch, on the thread page, in the reel, on the board —
puts the **composer under it straight away**. No button in between.

**The panel is a stack.** Tree → one of their Echoes → the whole thread it sits
in, each pushed on top of the last, each with a back button that names what it
returns to. **Open the whole thread** opens it *here*, with every reply, not on
another page. At the bottom of the stack the button reads **← Back to walking**
and closes the panel, leaving you exactly where you were standing. On an iPad in
portrait the panel is a sheet you can drag between half-height and nearly full.

The three-step walkthrough has **Next** and **Skip**, and the **?** in the
corner replays it.

**Board** is the second view: every Echo anyone has left, as tiles, filterable,
switchable between *Everyone's* and *Mine*. The archive doesn't appear here;
the board is people only.

---

## Reel

Any thread, full screen, one Echo per swipe.

- Film and photo fill the screen, with a blurred still of themselves behind.
- Voice gets a live waveform, a big play control and the time.
- Written gets the whole screen as a page, in large serif type, with the author
  on the card.
- Top: back · **3 / 11** · sound. A **format chip row** with counts under it,
  and a **progress rail** down the right edge.
- Right rail: heart · replies · add.
- **Replies** come up from the bottom over the Echo, carrying the same composer
  as the thread page — you can answer, with an attachment, without leaving.
- The last slide offers: add to this thread · swipe through again · back.

---

## The documented history

Separately from the invented Echoes, the prototype now carries real, sourced
history.

**Each of the five landmarks has a History tab** beside its Echoes: how the
Great Court was built in stages over forty years and why the sandstone is every
colour at once; who William Forgan Smith was and what the army did with his
building from August 1942; why Duhig is the only Great Court building not named
after a professor, and whose grotesque stands outside the library he founded;
what came out of the UQ Lake when it was drained in 2022 — 541 long-finned eels,
251 turtles and one 127 cm Queensland lungfish; and the flood heights at the
Brisbane City gauge in 1893, 1974, 2011 and 2022.

**Forty-one documented records** sit inside the threads, marked **ARCHIVE**,
each with a link to its source: the 1967 civil liberties march, 4ZZZ's first
broadcast and its eviction, the 418 people arrested in Brisbane on one afternoon
in October 1977, the five thousand outside Mayne Hall in 1985, Merle Thornton at
the Regatta, Ernest Bick and his 130 jacarandas, Joseph Croft in 1944 and
Margaret Valadian in 1966, and the Aboriginal and Torres Strait Islander Studies
Unit from its 1984 enclave programme.

**Where the sources disagree, it says so.** The 1967 arrest count is given as
114, with some sources saying 120 or 144. UQ's own records differ on whether
Bjelke-Petersen's honorary doctorate was 1984 or 1985. UQ dates the lake to the
late 1940s but its own magazine has pines planted around it in 1939. None of
those is resolved by guessing.

**One finding worth knowing.** I went looking for UQ's Acknowledgement of
Country so the prototype could name the Traditional Owners of this campus. UQ
publishes no names — not on its reconciliation pages, not in its Stretch
Reconciliation Action Plan, which instead contains a commitment to produce a
document "identifying Traditional Owners on all UQ campuses and sites". UQ itself
treats this as unfinished, and the prototype now says that, with the source. The
one river name that is verifiable from a Queensland Government source is
**Maiwar**, which the Queensland Redistribution Commission describes as "a word
used by some Aboriginal people to refer to the Brisbane River" — the hedge is
theirs and it is kept.

## The seventh theme: the ground it stands on

*The river bend, the trees, the sandstone, and whose Country this is.*

Eight threads — the Acknowledgement before every lecture, the river bend this
sits in, trees older than the buildings, what I was never taught about this
place, heritage listed and still in use, the names on the buildings, walking the
same ground, and what I'd want a visitor to know.

**Every thread in it carries a notice at the top**, in its own card, that says:

> This theme is a prototype placeholder. Everything in it is written for this
> demonstration, in the voice of invented students. Nothing here speaks for
> Aboriginal or Torres Strait Islander people. Content that does has to be made
> with Traditional Owners, through the University's Aboriginal and Torres Strait
> Islander Studies Unit — not written by a designer, and not generated.

That notice is part of the design, not a stub to be quietly deleted before the
hand-in. No Aboriginal or Torres Strait Islander stories, names, language or
cultural knowledge have been invented and presented as real anywhere in this
build. What is here is invented **student** voices about their own experience —
the Acknowledgement becoming routine, finding out late, not knowing what to do
with it — and threads that ask questions rather than assert history. In a crit,
naming the gap and the process for filling it is a stronger answer than
content somebody in the room will recognise as invented.

## The media, and how it is made

Every photograph, film and voice note in the archive is **generated by the app
itself** — none of it is a recording of a real place or a real person:

- **Photographs and films** are pixel scenes drawn in code: a sandstone
  arcade, the lake at dusk, the refectory queue, a noticeboard nobody has
  cleared, a crowd on the steps, the back of a lecture theatre, jacaranda over
  a path, a desk at three in the morning, the library stacks, the river at the
  terminal, a graduation on the lawn, a dim corridor, a band in a small room,
  rain on a path, an empty bench, market stalls. Sixteen of them, matched to
  Echoes by the words people actually used. The films are the same scenes with
  the petals falling, the water glinting or the lights moving, and a play /
  pause control.
- **Voice notes** are a short synthesised tone track with a drawn waveform —
  genuinely playable offline — and **what was said is printed underneath** as a
  transcript.
- Every one of them carries a **SIMULATED IMAGE** mark, and the voice player
  says plainly that it is a tone with the words below.

All fifty-five threads have all three formats, so nothing anywhere opens onto
an empty tile. The media is handed to the middling Echoes rather than the long
ones, so the best writing stays written.

## Simulated, and labelled

Sixteen other people, their Echoes, their replies, the threads they follow,
their activity, the answer that arrives a few seconds after you leave
something, and what anyone is "reading now" are all invented, and the profile
panels say so. So are every generated photograph, film and voice note. The pods
aren't connected to each other and there is no server. Your own ID, your
Echoes, your saves, your likes and your notifications are real and live on
that iPad.

The artwork is all drawn by the app: cubes, plates and pixel squares generated
in code. Nothing is traced from a photograph, and no game's or toy company's
assets, textures or character designs are used or included.

## Gone

Comments · the six Echo types · the subtopic screens · the format-picking
screen before you write · the second screen in Share · the filters modal ·
"+ New thread" and "Somewhere else" at the bottom of a thread · trails and
following · the profile avatar · Connect another Echo.
