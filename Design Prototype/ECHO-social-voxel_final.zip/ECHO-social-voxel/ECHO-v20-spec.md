# ECHO v20 — the small things, done properly, and a seventh theme

Written before building.

Four of these are UI faults you spotted in the screenshots. The fifth is
content, and it is the biggest piece of work in the round.

---

## 1. The bubble doesn't go away

**Screenshot 1.** You walk up to Forgan Smith, tap **Look around**, the place
opens — and *Forgan Smith · Look around ›* is still sitting there over the
grass, offering you something you are already doing.

**Why:** the proximity check runs every frame and re-shows the bubble as long as
you are standing near something. Opening the panel hid it once; the next frame
put it straight back.

**Fix:** the bubble is suppressed while **anything** is open — a place, a tree, a
thread, an Echo, a conversation. It comes back the moment you close the panel
and are still standing near something. One rule, one line, applies everywhere.

---

## 2. Nothing takes you out of the garden. Nothing.

**Screenshot 2.** **Leave something here** throws you onto the full-screen
Share page. You asked for this not to happen anywhere, and it was the last
place it still did.

**Fix:** **Leave something here** opens a **box inside the panel**, under the
list, exactly like the one under every Echo:

> **Leave something here** — *The Great Court · "Rumours about the tunnel"*
> ```
> ┌───────────────────────────────────────────┐
> │ Say something about this place…           │
> └───────────────────────────────────────────┘
>  📷 Photo   🎤 Voice   🎬 Film              [ Post ]
> ```

Write it, or attach a photo, a voice note or a clip, or both. **Post** files it
to the thread that fits the place, the flower lands on your tree, the panel
repaints with your Echo at the top of the list — and you are still standing
where you were, still in walk mode.

The same box replaces the last two jumps out of the garden:

- the **+** in the garden's top-right (it now opens the box over the island,
  filed to wherever the pod guesses, with **Move it** if the guess is wrong);
- **+ Add** on an Echo whose card isn't on screen.

After this round, nothing inside the UQ garden navigates anywhere. The
full-screen Share page stays for the main menu's **Share something** door,
which is where it belongs.

---

## 3. The ⋯ button

**Screenshot 3.** The three dots that bring the prompts back sit low and
off-centre in their circle.

**Why:** it was the character `⋯`, and that glyph's position inside its line box
is up to the font. At 42px in a circle, it lands wherever the font says.

**Fix:** three drawn dots instead of a character, centred by the layout rather
than by typography. Same for every other place in the build that used that
glyph as a control.

---

## 4. The flower, open

**Screenshot 4.** Opening a flower draws a pale box round it. It reads as a
bug, and it is one — a leftover "glow" shape that should have gone when the
white square was fixed in v17.

**Fix:** the box is deleted. An open flower shows it is open by **becoming
purple**:

- its four petals take **UQ purple (#51247A)**, the corner petals the lighter
  **#8C79C4**, and the centre a gold pip;
- it lifts and scales up slightly, as now;
- the chain line to its parent Echo brightens, so you can see what it answers.

Nothing is drawn behind it, so there is no box, no square and no pale
rectangle at any zoom. Closed flowers keep their species colour, so the one you
are reading is the only purple thing on the tree.

---

## 5. A seventh theme: **The ground it stands on**

This is the one worth taking seriously.

The six themes so far are all *student life* — protest, music, food, study,
places, the generation before. Nothing in them is about **the place itself**:
the river bend the campus sits in, the trees that were here first, the
sandstone, the names on the buildings, and whose Country all of it is.

So: a **seventh theme**, and it gets the same treatment as the others — eight
threads, a full set of Echoes, media, the lot.

**The ground it stands on** — *The river bend, the trees, the sandstone, and
whose Country this is.*

Eight threads:

| | |
|---|---|
| **The Acknowledgement before every lecture** | What people actually think and feel when it's read, including the honest discomfort of hearing it become routine |
| **The river bend this sits in** | The campus is almost an island; what that does to how it feels |
| **Trees older than the buildings** | The fig, the gums, the ones that were here before any of it |
| **What I was never taught about this place** | People finding out, late, that there's a history under the one they were given |
| **Heritage listed, and still in use** | Studying in a building that is itself an exhibit |
| **The names on the buildings** | Who gets commemorated, who doesn't, and the arguments about it |
| **Walking the same ground** | Paths that existed before the paths |
| **What I'd want a visitor to know** | The thing you'd say if someone had five minutes here |

### How the First Nations material is handled

**I am not going to invent Aboriginal or Torres Strait Islander stories,
language, names or cultural knowledge and put them in the pod as if they were
real.** That would be the wrong thing to do in a prototype that is going to be
shown to people, and it would be worse than useless to you in a crit — it's the
kind of thing that sinks a project.

What goes in instead:

1. **Student and staff voices**, invented like everything else in here, about
   their *own* experience of the Acknowledgement, of learning this late, of not
   knowing what to do with it. That is honest material and it is what a pod in a
   corridor would actually collect.
2. **A pinned card at the top of the theme**, visually distinct, that says
   plainly: *this theme is a placeholder. The content here is written for the
   prototype. Anything that speaks for Traditional Owners has to be made with
   them, through the University's Aboriginal and Torres Strait Islander Studies
   Unit and the relevant community — not written by a designer or by a model.*
   It names that as the next step rather than pretending it's done.
3. **Prompts, not claims.** The threads ask questions and collect answers. They
   don't assert history.

That card is also the honest answer for your submission: it shows you've
identified the gap and know how it has to be filled, which reads far better
than invented content that someone in the room will recognise as invented.

### And more depth everywhere else

You're right that a lot of the existing Echoes are one-liners. One-liners are
realistic, but a feed of nothing else has no weight to it.

So: **about seventy longer Echoes** spread across all seven themes — three to
six sentences each, with a specific detail and a turn in them. The kind of
thing somebody would actually stop and read:

- the person who kept the flyers nobody else kept, and what's on them now;
- the note found in a beanbag in the library, and what they did about it;
- the photograph of a grandfather in the Great Court, and what changed between
  the two pictures;
- the week someone sat in the same seat every day because of who was in the
  next one;
- the thing a tutor said once that the person has carried for four years;
- the last day, and what they left behind on purpose.

Running jokes still cross between threads, the short replies stay short, and
the mix is uneven on purpose — but now there's something to find.

Everything is written for this prototype. Nothing is taken from Reddit or
anywhere else, no real person is named, nothing is presented as a dated
historical fact, and the generated photographs, films and voice notes stay
marked as simulated.

---

## What stays

Everything from v19: walking as the default, the panel stack, tappable
landmarks and plaques, the ⋯ menu on your own Echoes, the rebuilt conversation
panel, the five buildings, the generated media, the three doors.

## Tested

Real taps at 768×1024, 820×1180 and 834×1112 portrait plus two landscape sizes,
on: opening a place and seeing the bubble go, posting from inside the panel
without the screen changing, the ⋯ button's dots sitting centred, an open
flower having nothing drawn behind it, and the new theme appearing everywhere a
theme appears — Discover, the strip, the filters, the garden search and
Surprise me.
