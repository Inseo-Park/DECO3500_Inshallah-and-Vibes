# ECHO v18 — the garden, properly

This round is **only** the garden. Discover, threads, the composer, Reel,
Share, the board and the profiles are not touched.

Five things.

---

## 1. People who look like people

**Now:** three cubes stacked. It reads as a placeholder, because it is one.

**Change:** a proper little figure, built the way everything else here is —
out of blocks, but enough of them to be somebody:

- **Head** with an actual face on the side you're looking at: two eyes, a
  mouth, eyebrows. It turns with them, and you see the back of their head when
  they walk away from you.
- **Hair** as its own shape on top — five kinds (cropped, long, bun, curls,
  cap) in six colours.
- **Torso** with a shirt colour, a collar and a belt line.
- **Two arms**, separate from the body, that swing when they walk.
- **Two legs**, separate, that alternate. They stop mid-stride when the person
  stops.
- **Something that is theirs**: a backpack, a tote, headphones, a coffee cup,
  a skateboard under one arm. One each, fixed to their ID, so you start
  recognising people.

Sixteen people, each with a fixed combination, so MANGO-31 is always the one
with the headphones and the green shirt. Your own figure is in UQ purple with a
gold band, so you can always find yourself.

**A note on the look:** everything is still drawn by the app out of cubes and
pixels. I'm not copying Lego's minifigure or anyone else's character assets —
those are their designs. This is an original blocky figure in the same family,
which is what you actually want on a university prototype anyway.

---

## 2. Five places you can walk to

The island stops being a lawn with trees on it and becomes a small map of
St Lucia with **five landmarks** built out of blocks:

| | What's there |
|---|---|
| **The Great Court** | A ring of sandstone cloister arches round a lawn, jacarandas at the corners, the graduation steps |
| **Forgan Smith** | The long sandstone front with its clock tower and the tunnel arch underneath |
| **Duhig Library** | The square modern block, windows lit, the steps and the bike racks |
| **The Lakes** | Water, reeds, a bench, and the birds that run the place |
| **The Ferry Terminal** | A jetty out over the water with a CityCat at it |

Each one has a name plate, and **walking up to it** brings up a bubble —
*The Great Court · Look around*.

Tapping that opens the **place panel**:

- what the place is, in a line;
- **every Echo anyone has left that is about this place** — found by matching
  the words people actually used (sandstone, cloister, graduation, ibis, the
  CityCat, the clock, level 4…) against all 438 Echoes, so it is real content,
  not a stub;
- how many there are, and which thread each came from, tappable;
- and **Leave something here**, which opens the composer already filed to the
  thread that fits the place.

Paths join the landmarks to each other and to the grove of trees, so the island
reads as somewhere you walk around rather than a field.

---

## 3. Talking becomes a group

**Now:** you talk to one person, and the three opener chips sit there taking up
a third of the panel the whole time.

**Change:**

- The **openers only appear at the start**. Once three things have been said
  they fold away into a small **⋯** button, and the conversation gets the
  space. Tapping **⋯** brings them back.
- **Other people join.** Anyone walking within range of a conversation wanders
  over and joins it — *SANDSTONE-16 wandered over* — and from then on you're in
  a group. Up to four people.
- Everyone who has joined is shown as a row of faces at the top of the panel,
  and each line is labelled and coloured by who said it.
- People **answer each other**, not only you. Ask what someone left and someone
  else might say they've read it. Say something and two of them might both have
  an opinion.
- **Leave** ends it for you; they stay talking and wander off after a bit.

Still written into the app — no network, no model — and the panel still says
so, in one line at the bottom instead of a block in the middle.

---

## 4. Walking stays walking

**Now:** walk up to a tree, go in, come back out — and you're dumped into the
aerial view, standing nowhere.

**Change:** walk mode **suspends** rather than stops. You come back out of the
tree exactly where you were standing, still walking, facing the same way. The
back button reads **← Back to walking** while you're inside, so it's obvious.
The same for the place panels and for conversations.

---

## 5. No glitches

The specific ones this round:

- The character redraw is capped at 30fps and the camera only moves when you
  do, so the island doesn't shimmer while you stand still.
- Characters sort properly with the trees and landmarks — somebody behind a
  building is behind it, not drawn over the top of it.
- Nothing you can tap moves under your finger: bubbles and panels are docked.
- The dpad, the panels and the bubbles never capture a drag meant for the
  world, and the world never swallows a tap meant for them.
- Everything stops under reduced motion.

---

## What stays

Aerial view, the flag on your tree, ⚑ My tree, the pod map, the walkthrough,
trees that grow with the person, edit and delete, the flower when you leave
something, and every screen outside the garden.

## Still simulated, and labelled

The sixteen people, what they say alone and in a group, the pod map and its
numbers. Drawn by the app from cubes and pixels — no texture pack, no game's or
toy company's assets.
