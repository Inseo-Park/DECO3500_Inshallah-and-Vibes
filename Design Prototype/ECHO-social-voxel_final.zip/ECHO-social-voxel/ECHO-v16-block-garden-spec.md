# ECHO v16 — the block garden, fixed

Written before anything is built. This round only touches the **block garden**
build (`ECHO-social-voxel`). Discover, threads, the composer, Reel, the board,
Share and the profiles are not changing.

Eight things — five planned, three you added while it was being built.

---

## 1. The ground is solid, and every tree stands on it

**Now:** the island is one big flat plate and the trees are placed at
hand-picked coordinates on top of it. Some of them sit past the edge or half
over the water, so they read as floating.

**Change:**

- Trees are **snapped to tile centres** on the same isometric grid the ground
  is drawn on. A tree can only ever stand on a tile that exists.
- The plate is sized **from the tree layout**, not guessed — it is built to
  contain every tile a tree stands on, with a four-tile margin all round.
- The water and the path are carved out of tiles that **no tree stands on**,
  checked rather than assumed.
- Each tree gets a **raised block of earth under it** — one cube of dirt with
  a grass top, so the trunk visibly meets ground instead of hovering over a
  flat green field.
- The island gets a proper **thickness**: a dirt wall down both near edges and
  a stone layer under that, so it reads as a chunk of the world rather than a
  sheet of paper.

---

## 2. Trees grow with the person

**Now:** every tree is the same shape, scaled slightly by how many Echoes the
person has left.

**Change:** growth is **everything they've done** — Echoes left, answers those
Echoes have received, and threads they follow — turned into one score, which
decides four things at once:

| | Sapling | Young | Grown | Old |
|---|---|---|---|---|
| roughly | 1 Echo | 2–4 | 5–9 | 10+ and answered |
| trunk | 2 blocks, thin | 4 | 6 | 8, **2×2 thick** |
| canopy | 1 layer | 2 | 3 | 4, wider |
| extras | — | — | one side branch | two side branches, roots at the base |
| ground | — | — | — | fallen petals on the tiles around it |

So a first-year who has left one thing has a visible sapling with one flower
on it, and someone five years in with a long history has a thick, broad,
many-flowered tree — and you can tell which is which from across the island
without reading a single name.

Species still varies the colour and the crown shape, so no two grown trees
look the same either.

---

## 3. Walking into a tree stops glitching

**Now:** zooming into a tree shows white rectangles behind it (the sky layer's
clouds, drawn in front of nothing), the camera stutters, and leaving is
unclear.

**Change:**

- A **solid sky plane** behind everything, so there is never white showing
  through — the clouds sit on top of it rather than on nothing.
- Inside a tree the **sky and distance layers freeze and dim**: no drifting
  clouds, no birds, no parallax while the camera is moving. That is most of
  the stutter.
- `shape-rendering: crispEdges` on the world, which both suits a blocky
  picture and takes the anti-aliasing cost off a few thousand shapes.
- The **sway animation stops** on every tree except the one you're in, and
  stops entirely while you are dragging.
- The camera's fly-to is **one animation, not two** — entering a tree
  currently re-centres twice, which is what the jump looks like.
- Leaving is one obvious control: **← Back to the garden** stays in the top
  left the whole time you are inside, and the same button reads **← Back to
  the tree** when a flower is open. Tapping the ground behind the panel also
  backs out one step.

---

## 4. The walkthrough explains what the garden is, then takes you to your tree

**Now:** three cards that say how to drag and tap. They don't say what the
place *is*, and a first-timer has no idea which tree is theirs.

**Change:** the garden opens on **the whole island** for a moment — long
enough to read it as a place with people in it — and then the camera **flies to
your own tree** and marks it. Four cards:

1. **1 of 4 — What this is.** *Every tree here is one person who has left
   something at a UQ pod. Its flowers are their Echoes. Walk into a tree and
   you can read what they left and which threads they follow.*
2. **2 of 4 — This one is yours.** (The camera has just flown to it; the tree
   is outlined and its name plate is highlighted.) *Your tree grows as you
   leave things. Right now it has N flowers on it.* → **Walk in**
3. **3 of 4 — Inside your tree.** *Your Echoes, what you've saved, what you've
   been doing, and who has answered or liked your things.*
4. **4 of 4 — Everyone else.** *Back out and walk into anyone's tree to see
   their Echoes and what they follow.* → **Got it**

Every card has **Next ›** and **Skip**, as now, and doing the action moves it
on too. The **?** in the corner replays it from the start.

If the person has left nothing yet, card 2 reads *This one is yours — it's a
sapling, because you haven't left anything here yet. The + plants the first
flower on it.*

---

## 5. Smaller things, while we're in there

- Name plates only on trees that are not currently zoomed in on, so the plate
  doesn't sit over the trunk when you walk in.
- The **◉** button is relabelled in the hint text as *see the whole island*,
  since that is now the thing people will want most.
- Fallen petals under grown trees, so the ground isn't uniformly green.

---

---

## 6. Your own Echoes are yours to change or take back

*(Added mid-build. This one is in **both** builds, not only the block one.)*

Every Echo you left carries **Edit** and **Delete** next to its heart. Nobody
else's does.

- **Edit** opens the words in place, under the card, with Save and Cancel. The
  card afterwards says *edited*, quietly, so nothing is silently rewritten.
- **Delete** asks once — the button becomes **Really delete?** for three
  seconds — and then takes the Echo and everything people added to it. The
  confirmation says how many answers went with it.
- Both work everywhere an Echo of yours appears: the thread page, the reel's
  reply drawer, the board, and on a flower in the garden.
- Both survive closing the pod. The demo account rebuilds itself on every
  resume, so it keeps a record of what you changed and deleted and re-applies
  it, rather than resurrecting things you got rid of.

## 7. Finding your own tree

*(Added mid-build.)* Every tree looked the same, so yours was impossible to
find. Now:

- Your tree flies a **maroon banner** on a pole, with a **lantern block** at
  the base — visible from right across the island, over the top of everything.
- Your ground is a **lighter clearing**: four pale grass tiles around your
  plinth.
- Your name plate is **maroon with a gold bar** and reads **· YOU**, where
  everyone else's is plain dark.
- A **⚑ My tree** button sits above the zoom controls, always. It flies you
  home and walks you in from anywhere, including out of somebody else's tree.
- The hint line says it: *Drag to walk · tap a tree to see whose it is · ⚑ is
  yours.*

## 8. The island looks like somewhere

*(Added mid-build.)* Beyond the fixes above:

- **Paths that join the trees up** — a dirt track laid between each
  neighbouring pair, so the island reads as a place people walk through rather
  than a lawn with things on it.
- Three greens and bare earth in the ground tiles instead of one flat colour,
  with seams between every tile.
- A **thickness**: grass lip, then soil, then stone, down both visible edges.
- Scatter with some range to it — bushes, two-block shrubs, rocks, logs, wild
  flowers and grass tufts — and none of it on a tile where somebody is
  standing or where the path runs.
- Water in the far corner with lily pads, placed where no tree is.
- Hills behind the island in the same layer as the ground, so they can't slide
  over the top of it when the camera moves.
- Pale barks darkened, so paperbark and gum stop reading as concrete.

---

## What is not changing

The painted-garden build (`ECHO-social/`) is untouched. In the block build,
everything outside the garden screen — Discover, threads, filters, the
composer, Reel, Share, the board, the profiles, the demo account and its
alerts — stays exactly as it is.

## Still simulated, and labelled

The sixteen other people, their Echoes, saves, activity and answers; the demo
account LAKEWALKER-07 and its alerts. The artwork is generated by the app from
cubes and pixel squares — no texture pack, no game's assets.
