# ECHO — final prototype

Built for an **iPad held in portrait**. Two megabytes, three files, no internet.

```
ECHO/
  index.html      ← open this
  README.md
  media/
    echo-027-clip.mp4    23 seconds of film
    echo-027-clip.mp3    the same 23 seconds, sound only
    echo-027-clip-poster.jpg
```

Keep the folder together. If you see *"Can't find the recording"*, `index.html`
has been separated from `media/` — extract the zip properly rather than opening
the HTML out of it.

**On the iPad:** open `index.html` in Safari, then Share → **Add to Home Screen**.
Launched from the home screen it runs full-screen with no address bar, which is
what you want on a pod.

---

## What changed after the testing

**Three screens became one.** The "touch to begin" attract screen is gone — it
opens straight on ECHO with the two choices. *What's an Echo?* moved into the
**i** button at the top right, so the people who want it can get it and everyone
else isn't made to read it first. Testing said people won't tap through screens
that don't do anything, and those two screens didn't.

**The story is 23 seconds.** Cut from the 1967 sit-down — four thousand students
marching without a permit, arms linked in the road, a hundred arrests. The full
four-minute film and the five-and-a-half-minute audio were both far too long.

**Three ways in, not two.** Watch it, listen to it, or **read it**. Reading was
the missing one: it's the fastest, it works with no headphones, in bright sun,
and with someone standing next to you. I'd expect it to get picked more than
you'd like.

**Reacting happens during, not after.** Under the piece — whichever of the three
you picked — there are four emoji, **what other people said**, and a box to say
something back. One less tap, and people react while they still feel it.

**The comments are real.** Four seeded ones make it feel lived-in on day one;
everything a participant posts is kept and shown to the next person who sits
down. Which is the whole idea of ECHO working in miniature, on one iPad.

**A moment became a photo.** You were right that a memory and a moment were the
same question. That slot is now **A photo**.

**Three ways to leave it, on one screen.** After picking what kind of thing it
is, there's a Write / Record / Photo switcher — no extra screen, and people can
change their mind without going back.

The full path is now: **home → curious about? → which one? → watch/listen/read →
leave something → done.** Six taps to finish, against eleven before.

---

## Camera and microphone

**Photo works everywhere.** Tap **Take a photo** and iPadOS offers Take Photo or
Photo Library, so a group shot already on the camera roll works as well as a new
one. It's a file picker rather than a live viewfinder on purpose — Safari refuses
live camera access to a page opened from a file, so a viewfinder would just fail.
Photos are scaled to 1100px and held for the session.

**Recording has one catch, and it's an iPad one.** Tap the red circle, speak, tap
again; there's a live level meter and a 45-second cap, then you play it back and
keep it or redo it. That works on a laptop.

On an **iPad opening this from a file, the microphone will be refused** — Safari
only allows microphone access over https, and a local file isn't. When that
happens the screen says so plainly and points at Write and Photo rather than
sitting there doing nothing.

If you need voice working on the iPad, say so and I'll publish this as a hosted
page. Over https the microphone and a live camera both work, and it's the same
prototype otherwise — the trade is that the iPad needs wifi and to be signed in
to your Claude account.

---

## Seeing what people did

Nobody's being surveyed now, but the pod still records quietly — it costs nothing
and a pod that records nothing can't tell you anything.

**Press and hold the small round icon** in the bottom-right corner for about a
second. It only appears on the first and last screens, so it never sits over the
player and participants never meet it mid-story. On a laptop, **Ctrl/Cmd + Shift
+ D** also works.

You get a card per session: how they came in, what they were curious about, which
format they chose, how many seconds they actually played, what they reacted with,
anything they typed, and what they left. **Save CSV** opens the iPadOS share
sheet — Save to Files, mail it, or AirDrop it.

---

## Changing things

Everything editable is at the top of the `<script>` in `index.html`:

- **`STORY`** — title, the hook line, the read-it text, which files play
- **`SEED_COMMENTS`** — the four comments that are there before anyone arrives
- **`CURIOSITY`** and **`SUBTOPICS`** — the choice screens
- **`FORMATS`** — the three ways in
- **`REACTIONS`** — the four emoji
- **`ECHO_TYPES`** — the six things someone can leave
- **`ECHO_COUNT`** — the mocked 143

To swap the clip, drop a new `echo-027-clip.mp4` and `.mp3` into `media/` under
the same names. If the audio changes, the waveform won't match it any more — it's
drawn from a measured amplitude map embedded in the file (search `WAVE`), because
a browser won't analyse a local audio file live. Ask me to regenerate it.

---

## Worth knowing before you run it

**Every path still leads to the same 23 seconds.** Four curiosity options, nine
subtopics, one story. Nobody doing a single session notices, but anyone who sits
down twice will. If you're testing with people who might go round again, either
say it's one story for now, or let me cut two more clips from the film.

**The film's audio is what plays under "listen to it"**, not the ElevenLabs
piece. That way all three formats carry the same 23 seconds, which is the only
way "watch vs listen vs read" is a fair comparison. The immersive audio is still
in my workspace if you'd rather use it.

**Nothing anyone leaves is published.** Photos, recordings and messages stay on
that iPad and go no further. Comments are the one exception, by design: they're
kept on the device so the next person sees them. Clear the browser's site data
between rounds if you want a clean slate.
