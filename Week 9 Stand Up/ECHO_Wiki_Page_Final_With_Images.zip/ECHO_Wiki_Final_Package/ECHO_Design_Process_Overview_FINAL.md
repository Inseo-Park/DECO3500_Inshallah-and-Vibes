# ECHO — Design Process Overview

> **ECHO: Discover a story. Leave something behind.**  
> **DECO3500 Social & Mobile Computing — Semester 2, 2026**

ECHO is an interactive storytelling experience designed to connect students with UQ’s history, campus spaces and student experiences. Students can discover stories through audio, video or text, and leave their own memories, facts, questions or moments for other people to discover.

Our design goal was to create an experience that fits naturally into students’ existing routines, particularly during breaks, periods of downtime and moments when they are already spending time on campus.

---

## Project Links

- [Poster and promotional material](https://github.com/Inseo-Park/DECO3500_Inshallah-and-Vibes/blob/main/Week%209%20Stand%20Up/ECHO_Weeks6-8_Iterations_preview.pdf)
- [Digital prototype — ECHO](https://github.com/Inseo-Park/DECO3500_Inshallah-and-Vibes/blob/main/Week%209%20Stand%20Up/ECHO_1.zip)
- [GitHub repository](https://github.com/Inseo-Park/DECO3500_Inshallah-and-Vibes)
- [Week 9 stand-up documentation](https://github.com/Inseo-Park/DECO3500_Inshallah-and-Vibes/tree/main/Week%209%20Stand%20Up)
- [User research and interview findings](https://github.com/Inseo-Park/DECO3500_Inshallah-and-Vibes/blob/main/Week%209%20Stand%20Up/echo-sessions%20(2).csv)

> **Prototype note:** The digital prototype is an early proof of concept. It is not a fully deployed product and some interactions are demonstrated through prototype screens or Wizard-of-Oz facilitation.

---

## Prototype Access and Instructions

### Downloading the digital prototype

1. Open the [ECHO prototype ZIP file](https://github.com/Inseo-Park/DECO3500_Inshallah-and-Vibes/blob/main/Week%209%20Stand%20Up/ECHO_1.zip).
2. Select **Download raw** or download the ZIP file from GitHub.
3. Extract the ZIP file on your computer.
4. Open the extracted folder.
5. Locate the main prototype file.
6. Open the file using the appropriate browser or application indicated by the files inside the folder.
7. If the prototype does not open automatically, right-click the main HTML file and select **Open with → Google Chrome** or another modern browser.

### Exploring the prototype

Users can:

1. Enter the ECHO experience.
2. Choose between **Listen & Discover** and **Share Something**.
3. Select a story category or allow the experience to surprise them.
4. Experience a story through audio, video or text.
5. Respond to the story and describe what stayed with them.
6. Decide whether to leave an Echo for another student.

---

## 1. Project Overview

Our research identified an opportunity to help students connect with UQ’s history and campus identity in ways that feel relevant to everyday student life. Although students may be interested in campus stories, they do not always encounter this information naturally while moving between classes, studying or relaxing.

Instead of developing a conventional historical display, we explored a place-based storytelling experience that combines:

- Historical stories connected to UQ locations.
- Memories and experiences from students and other community members.
- Flexible content formats, including audio, video and text.
- Optional participation without requiring a team or scheduled activity.
- A physical installation integrated into familiar campus spaces.
- The ability to leave an Echo for another person to discover later.

The concept of an “Echo” creates an asynchronous social connection: one person leaves something behind, and another person encounters it at a later time.

![ECHO physical concept](https://github.com/Inseo-Park/DECO3500_Inshallah-and-Vibes/raw/refs/heads/main/Week%209%20Stand%20Up/ECHO_Wiki_Assets/04_physical_concept.png)

*Figure 1. Concept visualisation of the ECHO installation in a campus lakeside setting. This image represents the proposed direction rather than a completed installation.*

---

## 2. Design Process Timeline

| Week | Focus | Outcome |
|---|---|---|
| Week 6 | Idea generation and initial testing | Four concepts were explored and compared. |
| Week 7 | Concept selection | ECHO was selected as the final design direction. |
| Week 8 | Digital prototyping and user evaluation | The interaction flow and content preferences were tested. |
| Week 9 | Iteration and re-planning | Findings informed the physical and digital prototype direction. |

---

## 3. Week 6 — Exploring Initial Ideas

During Week 6, the team explored four different concepts related to campus history, discovery, interaction and belonging.

### UQ Board Game

The board game used team-based collection mechanics, clues and historical artefacts. Testing suggested that the purpose was easy to understand, but the activity could become too time-consuming or feel like “assigned fun.” Simple trivia also risked limiting the depth of learning.

### UQ Stories

UQ Stories was a digital storytelling platform containing short stories about campus history and lived experiences. Participants found the website intuitive and responded positively to stories connected to real locations. An interactive map was identified as a possible future improvement.

### Scavenger Hunt

The scavenger hunt used QR codes and physical movement around campus. Participants liked the idea of scanning a location to access information, but the concept required users to actively travel between locations and could be difficult to complete during short breaks.

### Story Pods

Story Pods proposed a quiet, semi-private listening and sharing space. Participants responded positively to the idea of discovering something left by another student and found audio combined with visuals engaging. However, a large enclosed structure could feel intimidating, leading to the decision to explore a smaller and more understated form.

![Design decisions from research](https://github.com/Inseo-Park/DECO3500_Inshallah-and-Vibes/raw/refs/heads/main/Week%209%20Stand%20Up/ECHO_Wiki_Assets/02_design_decisions.png)

*Figure 2. Summary of themes, evidence, insights and design decisions derived from student feedback.*

---

## 4. Week 7 — Selecting ECHO

ECHO was selected because it allowed students to participate flexibly without requiring a team, a fixed schedule or extended gameplay.

Compared with the other concepts, ECHO could:

- Be used by one student at almost any time.
- Support both individual and social experiences.
- Offer the historical depth of UQ Stories while allowing user contribution.
- Accommodate different attention spans and content preferences.
- Work in existing campus spaces.
- Build social value over time as more students leave stories and memories.

The final concept combined place-based historical storytelling, student contributions, optional participation and a physical installation. The design aimed to span the space between isolated and social experiences while remaining informative and accessible.

---

## 5. Week 8 — Developing the Digital Prototype

The digital prototype was developed before committing to a final physical installation. This allowed the team to test the experience structure and content preferences with less time and material investment.

The main interaction flow included:

1. Entering the ECHO experience.
2. Understanding what an Echo is.
3. Choosing between discovering and sharing.
4. Selecting a story category.
5. Experiencing a story through different media.
6. Responding to the story.
7. Deciding whether to leave an Echo for another student.

The prototype explored audio, video and text-based content. This was important because students have different preferences for consuming information, and a single format could exclude some users. Accessibility considerations also led to the inclusion of subtitles or text alternatives where appropriate.

---

## 6. User Evaluation

The user evaluation investigated usability, interest in UQ stories, content preferences, engagement time and comfort when interacting in public spaces.

### What we wanted to understand

- Would students engage with campus stories?
- Would they explore the experience independently?
- Which content formats would they prefer?
- Would they prefer short or more immersive stories?
- Would they feel comfortable interacting in a public setting?
- Would they want to leave something for another student?

### What we observed

Engagement varied between participants. Some users explored briefly and preferred a quick interaction, while others spent longer engaging with the content. Media preferences also differed: participants responded to different combinations of audio, video and text.

The physical form influenced comfort. A smaller, understated installation appeared more approachable than a large enclosed pod because users wanted to remain aware of their surroundings and avoid feeling overly exposed.

Location-based storytelling remained important. Connecting stories to specific campus spaces made the information feel more relevant and helped link historical content to students’ existing experiences.

![User testing in a campus setting](https://github.com/Inseo-Park/DECO3500_Inshallah-and-Vibes/raw/refs/heads/main/Week%209%20Stand%20Up/ECHO_Wiki_Assets/05_user_testing_01.jpeg)

*Figure 3. User evaluation of the ECHO prototype in an outdoor campus setting.*

![Additional user testing](https://github.com/Inseo-Park/DECO3500_Inshallah-and-Vibes/raw/refs/heads/main/Week%209%20Stand%20Up/ECHO_Wiki_Assets/06_user_testing_02.jpeg)

*Figure 4. Students interacting with the prototype and discussing the experience.*

---

## 7. What Changed After Testing?

### Physical installation

The initial direction involved a larger listening pod with a semi-private listening experience. Feedback suggested that a large enclosed structure could feel intimidating or attract unwanted attention.

The design therefore moved towards:

- A smaller, book-inspired installation.
- Integration with existing seating areas.
- Optional privacy without completely enclosing the user.
- A tablet or screen for the main interaction.
- A subtle activation cue, such as lighting.
- Visibility of the surrounding environment.
- A form that invites participation without forcing it.

![Updated physical design direction](https://github.com/Inseo-Park/DECO3500_Inshallah-and-Vibes/raw/refs/heads/main/Week%209%20Stand%20Up/ECHO_Wiki_Assets/03_design_direction.png)

*Figure 5. Updated design direction showing the relationship between place, content, time and physical comfort.*

### Digital experience

The digital prototype was refined to include:

- A clear entry point.
- Simple navigation.
- Multiple content formats.
- Short stories with optional deeper exploration.
- Location-based content.
- Opportunities to leave an Echo.
- A low-pressure interaction flow.
- Reflection prompts following each story.

These changes helped align the prototype with the central insight that students are more likely to engage when the experience is accessible, optional and integrated into existing routines.

---

## 8. Current Prototype Direction

The current ECHO concept consists of two connected parts.

### Physical installation

The physical installation is intended for familiar campus spaces such as seating areas, lawns and locations around UQ Lakes. The proposed structure may include a book-shaped form, a screen or tablet, subtle lighting and a hinge mechanism that allows the book to open.

The physical form is still a concept direction rather than a fully engineered product. Due to the short project timeline, low-fidelity materials and Wizard-of-Oz interactions were prioritised.

### Digital experience

The digital experience is the main storytelling interface. Users can listen to a story, watch a visual story, read supporting information, choose a story category, respond to an Echo and leave a memory, fact, question or moment for another user.

![Prototype and installation relationship](https://github.com/Inseo-Park/DECO3500_Inshallah-and-Vibes/raw/refs/heads/main/Week%209%20Stand%20Up/ECHO_Wiki_Assets/04_physical_concept.png)

*Figure 6. Proposed relationship between the physical installation and the digital storytelling experience.*

---

## 9. Limitations and Future Work

The project timeline limited the level of detail possible in the physical prototype. The user testing also focused primarily on an early digital prototype, so the findings may not fully represent behaviour around a real installation in a campus environment.

Further testing should investigate:

- Interaction in real campus locations.
- Accessibility and physical comfort.
- Story length and content format.
- Privacy, consent and moderation of contributed stories.
- Whether the installation attracts attention without disrupting the surrounding space.
- Whether students return to the experience and contribute over time.
- How the experience can represent different voices respectfully and accurately.

---

## 10. Team Contributions

The project was developed collaboratively by all four team members. Team members contributed to idea generation, research discussions, concept comparison, prototyping, user testing, analysis and iteration.

**Before submission, replace this section with the specific names and responsibilities of each team member**, for example:

- **Name:** Research, interviews and thematic analysis.
- **Name:** Concept development and physical installation.
- **Name:** Digital prototype and interaction flow.
- **Name:** Visual design, testing documentation and presentation.

---

## 11. Final Reflection

ECHO developed through an iterative process of exploring concepts, testing assumptions and responding to student feedback. The project moved away from large, competitive or highly structured activities and towards a flexible experience that students can discover during existing moments of downtime.

The most important design learning was that engagement depends not only on the content itself, but also on when, where and how the experience is encountered. Students have different amounts of time, different media preferences and different levels of comfort when interacting in public spaces.

ECHO therefore combines a low-pressure physical invitation with a digital experience that supports listening, watching, reading, responding and contributing. The next stage would be to test the installation in a real campus environment, refine the interaction details and further evaluate how ECHO could become an approachable part of everyday campus life.
