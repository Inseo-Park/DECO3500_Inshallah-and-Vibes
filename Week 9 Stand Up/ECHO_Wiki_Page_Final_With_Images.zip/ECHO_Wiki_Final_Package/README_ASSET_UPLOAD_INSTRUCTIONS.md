# ECHO Wiki Page — Upload Instructions

## Files included

- `ECHO_Design_Process_Overview_FINAL.md` — copy and paste this into the GitHub Wiki page.
- `ECHO_Wiki_Assets/` — images referenced by the Markdown page.

## Important: upload the images first

The Markdown page uses these GitHub raw image URLs:

`https://github.com/Inseo-Park/DECO3500_Inshallah-and-Vibes/raw/refs/heads/main/Week%209%20Stand%20Up/ECHO_Wiki_Assets/filename`

For the images to display, upload the entire `ECHO_Wiki_Assets` folder into:

`Week 9 Stand Up/ECHO_Wiki_Assets/`

The folder should contain:

- `01_existing_wiki_links.png`
- `02_design_decisions.png`
- `03_design_direction.png`
- `04_physical_concept.png`
- `05_user_testing_01.jpeg`
- `06_user_testing_02.jpeg`

## Recommended GitHub steps

1. Open the repository.
2. Open `Week 9 Stand Up`.
3. Select **Add file → Upload files**.
4. Upload all files inside `ECHO_Wiki_Assets`.
5. Commit the upload to the `main` branch.
6. Open the repository’s **Wiki** tab.
7. Open the existing ECHO design-process page.
8. Replace its content with the contents of `ECHO_Design_Process_Overview_FINAL.md`.
9. Select **Save Page**.
10. Check that all images display correctly.

If an image does not display, confirm that the filename and folder name match exactly, including spaces, underscores and capital letters.
