# ECHO — prototype v5

Built for an **iPad held in portrait**. About 15 MB, no internet, no login.

```
ECHO/
  index.html      ← open this
  README.md
  media/          6 films (v-*.mp4 + poster .jpg), 6 audio pieces (a-*.mp3), 6 photos (p-*.jpg)
```

Keep the folder together. If something says it *can't find the recording*,
`index.html` has been separated from `media/` — extract the zip properly rather
than opening the HTML from inside it.

**On the iPad:** open `index.html` in Safari, then Share → **Add to Home Screen**.

---

## What's new in v5

**An opening.** The pod now starts on a moving collage: eight columns of
everything that's been left here — film stills, photos, the first lines of the
written stories, little moving waveforms for the audio — drifting up and down at
different speeds. After a couple of seconds it dims and the **ECHO — a living
history** card comes up, then *"Stories, sounds and moments, left behind by the
people who sat here before you"*, then *"Take one. Leave a little piece of your
journey."* At about ten seconds it fades into the home screen. Tapping anywhere
(or **Skip**) goes straight there. It plays again every time the pod resets, so
between visitors it works as the thing that catches someone walking past.

**Reel mode filter.** Under the reel's top bar there's a row of chips:
**All · Film · Listen · Read · Photos**, each with a count. Tap one and the feed
rebuilds with just that kind, from the top. *All* puts the mix back.

**Subtitles button.** Every film has a **CC** button — next to play in Watch, and
on the right-hand rail in Reel mode. Turning it on shows a subtitle bar on the
film: *"Subtitles for this clip are coming soon."* The captions themselves aren't
made (the transcription tools are blocked in my workspace), but the control is
there and it's logged, so you'll know how many people reached for it. It stays
on across films once someone turns it on.

The session CSV has three new columns: `intro` (watched / skipped),
`reel_filter` (the last filter picked) and `cc` (turned on or not).

---

## What was new in v4

**Language switch.** A small globe with the language code (EN) sits top-right
on every browsing screen — the curiosity question, the subtopics, the format
choice, every Echo, and in Reel mode. It opens a sheet of nine languages
(English, 中文, हिन्दी, Tiếng Việt, 한국어, 日本語, Español, Bahasa Indonesia,
العربية). As agreed, it doesn't translate anything: pick one and a note says
"*Tiếng Việt is coming. You're seeing English for now.*" The choice is logged,
so you'll know which languages people reached for.

**View more, under every Echo.** Watch, Listen and Read all now end with a
**View more** strip below the comments — up to six other Echoes from the same
topic as thumbnails. Tap one and it opens right there; nobody gets sent to the
end. **Keep going →** in the footer steps through them in order, and if there
are more than six there's a *See all in Reel mode* button.

**It's full of things now.** 28 Echoes instead of one:

- **6 films** (23 seconds each) cut from different parts of the archive film —
  1960s campus, the 1967 march, the 1970s police line, 1977, 1980s, 4ZZZ.
- **6 audio pieces** — the sound of four of those films (1967, 1970, 4ZZZ,
  1985) plus two 26-second parts of the narrated ElevenLabs piece.
- **10 written stories** — your four (the Duhig reserve textbook, the traffic
  cone, never going to the top of Forgan Smith, the koala chem notes) plus six
  more: the longer 1967 read, short archive stories for 1970, 4ZZZ and 1985, and
  two in your stories' voice (the ibis, the bench).
- **6 photos** — the ones you sent, each with a caption and a made-up author.

Each one is tagged to one or more of the three topics (17–18 per topic). When someone picks a
topic and a format they get a **shuffled mix from that topic**, so two people
rarely see the same order. Every Echo has two to four seeded comments.

**Reel mode.** The first option on the format screen, in a dark card marked NEW.
It's a full-screen vertical feed of everything in that topic — film, audio,
writing and photos mixed so the same kind never comes three times running.
Swipe up for the next one; there are no next buttons. Films and audio start by
themselves as they come into view (muted if Safari insists, with a *Tap for
sound* button). Down the right edge: **Feel it**, **comments** and **Leave one**.
Comments slide in as a panel from the right, and people can post without leaving
the feed. After the last one there's a *Your turn* card: **Leave something**,
**Watch them again**, or **I'm done**.

---

## Camera and microphone

**Photo works everywhere.** Tap **Take a photo** and iPadOS offers Take Photo or
Photo Library, so a group shot already on the camera roll works as well as a new
one. It's a file picker rather than a live viewfinder on purpose — Safari refuses
live camera access to a page opened from a file, so a viewfinder would just fail.
Photos are scaled to 1100px and held for the session.

**Recording has one catch, and it's an iPad one.** Tap the red circle, speak, tap
again; there's a live level meter and a 45-second cap, then you play it back and
keep it or redo it. That works on a laptop.

On an **iPad opening this from a file, the microphone will be refused** — Safari
only allows microphone access over https, and a local file isn't. When that
happens the screen says so plainly and points at Write and Photo rather than
sitting there doing nothing.

If you need voice working on the iPad, say so and I'll publish this as a hosted
page. Over https the microphone and a live camera both work, and it's the same
prototype otherwise — the trade is that the iPad needs wifi and to be signed in
to your Claude account.

---

## Seeing what people did

Nobody's being surveyed now, but the pod still records quietly — it costs nothing
and a pod that records nothing can't tell you anything.

**Press and hold the small round icon** in the bottom-right corner for about a
second. It only appears on the first and last screens, so it never sits over the
player and participants never meet it mid-story. On a laptop, **Ctrl/Cmd + Shift
+ D** also works.

You get a card per session: how they came in, what they were curious about, which
format they chose, how many seconds they actually played, what they reacted with,
anything they typed, and what they left. **Save CSV** opens the iPadOS share
sheet — Save to Files, mail it, or AirDrop it.

---

## Changing things

All the content lives at the top of the `<script>` in `index.html`:

- **`ECHOES`** — every Echo: its kind (video / audio / text / photo), which topics
  it belongs to (`cat`), title, who left it, when, the file, and the text or caption
- **`SEED`** — the comments each Echo starts with, by id
- **`LANGS`** — the language list
- **`CURIOSITY`**, **`SUBTOPICS`**, **`FORMATS`**, **`REACTIONS`**, **`ECHO_TYPES`**

To add a photo, drop a jpg into `media/` and add a line to `ECHOES` copying one of
the existing photo entries. A new audio file's waveform won't match unless its
`wave` is regenerated — ask me.

---

## Worth knowing before you run it

**The films are all cut from the same archive film**, so the fake data is fake:
titles, authors, dates and captions are invented to make the pod feel lived-in.
The written stories labelled as archive pieces are loosely based on UQ protest
history, not researched history.

**Topic tags are a rough split**, and the subtopic someone picks (e.g. *What was
here before?*) is logged but doesn't narrow things further than the topic.

**Nothing anyone leaves is published.** It stays on that iPad. Comments are kept
on the device by design so the next person sees them. Clear Safari's website data
between rounds for a clean slate.
