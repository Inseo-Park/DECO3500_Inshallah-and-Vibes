# ECHO questionnaire — paste-ready

Everything below goes straight into Google Forms, Qualtrics, or whatever you're
using. The five images are in the `images` folder beside this file — upload all
five into question 4, labelled A, B, C, D, E.

**Settings worth turning on:** collect responses anonymously (don't collect email
addresses). Make 1, 3, 4a, 4b, 5, 6, 7 and 8 required; leave 2, 4c and 9 optional —
they're open text and people skip them, which is fine.

Where a question says *with an "Other" box*, turn on Google Forms' **"Other…"**
checkbox option. Those boxes matter: this is the round where you find out about
the places you haven't thought of.

---

## Form title

**Where do you disappear to on campus?**

## Description

We're designing something small and quiet to go where students already sit — the
spots around UQ people head for when they want a bit of time to themselves.
Somewhere you could sit, hear a story someone left behind, and maybe leave one
yourself.

Before we build it we need to know where you actually spend your time at UQ, and
what would make you stop. No right answers, and nothing here is graded. About two
minutes.

Anonymous — nothing you write is linked to your name.

---

## 1. Where do you spend time at UQ when you're not in class?

*Checkboxes, with an "Other" box — pick as many as are true*

Helper text: Anywhere you end up.

- UQ Lakes
- The Great Court
- A library
- My own faculty building
- The gardens down by the river
- A café — Wordsmiths, Merlo, wherever
- The Union complex or the food court
- The sport centre
- I don't hang around — I come for class and leave
- Other…

## 2. And when you want to be on your own — where do you go?

*Short answer — optional*

Helper text: Even if it's an odd spot. It won't be named in anything public.

## 3. When do you feel like you've actually got free time on campus?

*Checkboxes, with an "Other" box — pick as many as are true*

- Between classes
- Around lunch
- Before my first class
- After my last class
- Waiting for someone
- Whole gaps in the day with nothing in them
- Evenings
- Weekends
- Rarely — I'm on campus and then I'm gone
- Other…

## 4. If one of these turned up somewhere you sit

*Image block, then two multiple-choice questions and one open one*

Helper text: Five ideas for the same thing. Have a proper look, then answer both
below.

Upload all five images here, captioned:

- **A** — A slim lit post beside the bench (`images/opt-a.jpg`)
- **B** — A low plinth with a screen on an arm (`images/opt-b.jpg`)
- **C** — A large sculpted ear with a screen set into it (`images/opt-c.jpg`)
- **D** — An open book on a stone base (`images/opt-d.jpg`)
- **E** — A bench under a curved timber hood, with the screen beside it (`images/opt-e.jpg`)

### 4a. Which would actually make you stop?

*Multiple choice — required*

- A
- B
- C
- D
- E
- None would stop me

### 4b. And which would you most want to be there?

*Multiple choice — required*

Helper text: Not the same question — the thing that catches your eye isn't always
the thing you'd want to sit next to every day.

- A
- B
- C
- D
- E
- None of them

### 4c. Why those ones?

*Paragraph — optional*

Helper text: A sentence is plenty. This is the answer we learn most from.

## 5. If it was going to tell you something about UQ, what would you want it to be about?

*Checkboxes, with an "Other" box — pick as many as are true*

- Something that happened on this exact spot
- Students here decades ago
- People going through what I'm going through now
- Something the university doesn't advertise
- Something funny
- The lakes and the land itself
- Honestly, I wouldn't want a story
- Other…

## 6. Now imagine it was left by another student, for whoever sat there next — not made by the university.

*Multiple choice*

Helper text: Does that change anything?

- I'd be much more likely to listen
- A bit more likely
- Makes no difference to me
- A bit less likely — I'd trust it more if it were official
- It'd put me off

## 7. Would you put headphones on there, with people walking past?

*Multiple choice*

- Yes, happily
- Yes, but only my own headphones
- Only if nobody was around
- I'd rather it played out loud, softly
- No

## 8. Would you leave something behind for a stranger to find?

*Multiple choice*

Helper text: A memory, a fact, a question — whatever you wanted.

- Yes, written
- Yes, in my own voice
- Only if it were completely anonymous
- No

## 9. What would put you off using it?

*Paragraph — optional*

Helper text: The more blunt the better.

---

## What each question is actually for

Worth keeping straight when you write this up — several of these look like
preference questions and are really something else.

| Q | What it measures | Why it's in here |
|---|---|---|
| 1 | Where people already are | You can't site a quiet refuge without knowing the campus's existing gravity. The "Other" box is the point of this question as much as the list is. |
| 2 | The spots nobody advertises | The single answer most likely to move the project. These are installations for wherever people already sit, so this question is effectively the siting list. |
| 3 | The window of opportunity | Whether a 3–5 minute thing has anywhere to fit. "Whole gaps in the day" and "rarely" pull in opposite directions and the split matters. |
| 4a | Attraction | Spec §48's first success criterion, and the only thing the renders can answer on their own. |
| 4b | What they'd live with | Deliberately separated from 4a. What makes you look is often not what you'd want permanently in your spot — a gap between 4a and 4b is a finding, not noise. E is the one to watch here: the enclosed option is the likeliest to lose on 4a and win on 4b. |
| 4c | The reasoning | Counts tell you which. Only this tells you why, and it's where the unexpected objections show up. |
| 5 | Content appetite | Directs what gets produced next. If "students here decades ago" loses to "people going through what I'm going through now", the whole content strategy shifts away from archive material. |
| 6 | **The core premise** | The single most important question here. ECHO's entire concept rests on "someone left this for you" landing better than an official plaque. If it doesn't, that's the finding, and better to know now than after fabrication. |
| 7 | Whether audio works in public at all | Gates the audio-first design. "Only if nobody was around" scoring high would push siting toward the quieter, more tucked-away spots from question 2. |
| 8 | Willingness to contribute | The second half of ECHO depends on it. Watch the anonymity split closely. |
| 9 | The objection you haven't thought of | Open questions about barriers reliably surface what no multiple choice would have listed. |

### On what was cut

Two earlier questions came out: which physical form they'd use (open post / plinth
/ hooded seat / booth), and how long they'd give it before walking off. The first
is answered better by 4a and 4b, where people are reacting to something they can
see rather than to a written description. The second was worth asking, but a stated
guess at how long you'd stay is weak evidence — the prototype already measures how
long people *actually* last, which beats asking them.
