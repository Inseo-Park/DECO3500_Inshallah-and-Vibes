# ECHO questionnaire — what's in this folder

```
echo-survey/
  index.html              ← the questionnaire. Open this one.
  QUESTIONS-to-paste.md   ← the same questions, written out for Google Forms
  images/                 ← the five design renders, A to E
```

**Keep the folder together.** `index.html` loads the five renders out of
`images/`. Pull the HTML out on its own and question 4 loses its pictures.

---

## Running it on a device

Double-click **`index.html`**. No server, no internet, nothing to install. Good
for stopping people on campus with a phone or tablet in your hand.

The first time it opens on a device it asks **who's collecting** — initials or a
name. That gets stamped onto every response taken on that device and becomes the
first column of the CSV, so when several of you have been out collecting and the
files get merged, you can still tell whose is whose. You're only asked once, and
participants never see that screen. To change it later, open `#results` and click
**change** beside the name.

Responses are saved **in that browser, on that device**. There's no backend, so:

- Two devices means two separate sets of answers — including two browsers on the
  same laptop, since it's keyed to the browser, not the folder.
- Private or incognito windows keep nothing at all. Don't use them.
- Clearing the browser's site data wipes them.
- **Export the CSV at the end of every session.**

### Seeing the responses and exporting the CSV

Three ways in, the same as the ECHO pod prototype — use whichever you'll remember:

**1. The address bar.** Click at the end of the address, type `#results`, press
Enter:

```
file:///C:/Users/itish/Desktop/echo-survey/index.html#results
```

Bookmark that and it's one click forever after.

**2. Keyboard.** Press **Ctrl + Shift + D** (**Cmd + Shift + D** on a Mac).

**3. Touch.** **Triple-tap the middle of the very top edge** of the screen — for
when you're on a tablet with no keyboard.

Any of them gives you a tallied summary, every open-text answer listed underneath,
and a **Download CSV** button. The CSV lands in your Downloads folder and opens
straight in Excel or Google Sheets.

None of this is visible to anyone filling the form in — don't open it in front of
a participant.

---

## The hosted version

There's also a hosted copy of this questionnaire on claude.ai. It's the same
questions and the same design, but it saves responses centrally instead of
per-device, so it's the better one when you're running sessions across more than
one machine.

It can only be opened by you, though — a page that collects responses is
organisation-internal, which on a personal account means an audience of one. So
it works for surveys you administer yourself, and not as a link you post in a
class group chat.

## Running it as a team

Give each person the whole folder. Their copy collects independently — nothing
syncs, nothing overwrites, and nobody's answers reach anyone else's file.

Each person exports their own CSV at the end of each session. To merge, stack the
rows and delete the repeated header lines; every copy has identical columns, so it
pastes together cleanly, and the `collector` column tells you who took which
response.

If nobody's going to be out of phone reception, the Google Form below is less
work — one link, one sheet, nothing to reconcile.

## Sending it to lots of people

For that, use `QUESTIONS-to-paste.md`. Every question, option and helper line is
written out ready to paste into a Google Form or Qualtrics, with notes on which
questions to mark required and where to turn on the "Other…" boxes. Upload the
five images from `images/` into question 4.

That file also has a table at the end explaining what each question is actually
measuring and why it's there — worth keeping for the methodology section of your
write-up.
